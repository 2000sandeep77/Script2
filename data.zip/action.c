Action()
{

	web_url("banking", 
		"URL=http://localhost/banking", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	web_url("canonical.html", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_custom_request("r11.o.lencr.org", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\x1AR\\xB9\\xB4Y\\xE4\\xC33\\x98!~\\x86mK\\xBD\\x8A;\\xD6g\\xCE\\x04\\x14\\x08\\xB9\\x11;\\xA5\\xD0\\x85\\x18\\xB4\\xEA\\x0F\\xA0\\xAD\\x9F\\x86\\x1E\\x8E\\xFC8'\\x02\\x12\\x04n\\x93\\xA8\\xC3\\xD6\\xA6\\x99fu]\\x07p\\\\\\xD5\\x14?\\x82", 
		LAST);

	web_custom_request("r10.o.lencr.org", 
		"URL=http://r10.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14i\\x0F\\xE4\\x15g\\xEDo\\x7F\\xB54Dd\\x06\\x06o\tg\\x07qr\\x04\\x14t\\xA4v)\\x17\\x18T\\x8517\\xBEg\\xE6\\x06X\\xC0\\xBC\\xC5\\x05r\\x02\\x12\\x04v<\\xE7\\x12\\x13\\x0B\\xF0\\xD6\rq\\x0F9A\\x0Fi\\x9A\\x13", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt?ipv4", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("r10.o.lencr.org_2", 
		"URL=http://r10.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\x0Bh\\xA9.\\x99\\xC1d\\x83I\\xCEL\\xB5\\xD3R\\x89\\xBB\\xBA", 
		LAST);

	web_custom_request("r10.o.lencr.org_3", 
		"URL=http://r10.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x03\\xC3\nN\\xE0\\x18\\xCF\\x8BW\\x8E\\x01F\\xB4\\x85~&,D", 
		EXTRARES, 
		"Url=https://content-signature-2.cdn.mozilla.net/chains/remote-settings.content-signature.mozilla.org-2024-08-29-13-50-59.chain", "Referer=", ENDITEM, 
		LAST);

	web_url("v1", 
		"URL=https://firefox.settings.services.mozilla.com/v1/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("wr2", 
		"URL=http://o.pki.goog/wr2", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0R0P0N0L0J0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x11\\x00\\xA3\\x1D\\xB3|C\\x8F\\x01\\xC8\\x12l\\x05\\x97\\xC4d\\xE7\\x8E", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$ct=application/x-protobuf&key=AIzaSyC7jsptDS3am4tPx4r3nxis7IMjBc5Dovo&$httpMethod=POST&$req=ChUKE25hdmNsaWVudC1hdXRvLWZmb3gaJwgFEAEaGwoNCAUQBhgBIgMwMDEwARCYjhgaAhgKDuIttSICIAIoARonCAEQARobCg0IARAGGAEiAzAwMTABEPrrDhoCGAoRL0wRIgIgAigBGicIAxABGhsKDQgDEAYYASIDMDAxMAEQnOMOGgIYCp2hw40iAiACKAEaJwgHEAEaGwoNCAcQBhgBIgMwMDEwARCbsg8aAhgKJGjQhCICIAIoARolCAkQARoZCg0ICRAGGAEiAzAwMTABECMaAhgKX9GWVCICIAIoAQ==", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("r11.o.lencr.org_2", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04n\\x93\\xA8\\xC3\\xD6\\xA6\\x99fu]\\x07p\\\\\\xD5\\x14?\\x82", 
		LAST);

	web_custom_request("r11.o.lencr.org_3", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04n\\x93\\xA8\\xC3\\xD6\\xA6\\x99fu]\\x07p\\\\\\xD5\\x14?\\x82", 
		LAST);

	web_custom_request("r11.o.lencr.org_4", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14\\x1AR\\xB9\\xB4Y\\xE4\\xC33\\x98!~\\x86mK\\xBD\\x8A;\\xD6g\\xCE\\x04\\x14\\x08\\xB9\\x11;\\xA5\\xD0\\x85\\x18\\xB4\\xEA\\x0F\\xA0\\xAD\\x9F\\x86\\x1E\\x8E\\xFC8'\\x02\\x12\\x04A:Y\\xC9\\xB1ta\\xD5hh\\x01\\x0C\\x1EN\\x0CC\n", 
		LAST);

	web_custom_request("r11.o.lencr.org_5", 
		"URL=http://r11.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04A:Y\\xC9\\xB1ta\\xD5hh\\x01\\x0C\\x1EN\\x0CC\n", 
		LAST);

	web_custom_request("r10.o.lencr.org_4", 
		"URL=http://r10.o.lencr.org/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0S0Q0O0M0K0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x12\\x04Ra$\\xCC\\xD4\\xFF\\xD9\\x10\\xBF ;\\xE3\\xB9\\x11g\\xB0\\x92", 
		EXTRARES, 
		"Url=http://detectportal.firefox.com/success.txt?ipv4", "Referer=", ENDITEM, 
		LAST);

	web_custom_request("cfr-v1-en-US", 
		"URL=https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/ms-language-packs/records/cfr-v1-en-US", 
		"Method=GET", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_websocket_connect("ID=0", 
		"URI=wss://push.services.mozilla.com/", 
		"Origin=wss://push.services.mozilla.com/", 
		"SecWebSocketExtensions=permessage-deflate", 
		"OnOpenCB=OnOpenCB0", 
		"OnMessageCB=OnMessageCB0", 
		"OnErrorCB=OnErrorCB0", 
		"OnCloseCB=OnCloseCB0", 
		LAST);

	web_websocket_send("ID=0", 
		"Buffer={\"messageType\":\"hello\",\"broadcasts\":{\"remote-settings/monitor_changes\":\"\\\"1722394630668\\\"\"},\"use_webpush\":true}", 
		"IsBinary=0", 
		LAST);

	web_custom_request("ocsp.digicert.com", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x01\\xE0c\\x8B\\x9A\\xDF\\x9CB\\x9B\\x90\\xA4n\\xB9\\x86\\x06\\x06", 
		LAST);

	/*Connection ID 0 received buffer WebSocketReceive0*/

	web_custom_request("ocsp.digicert.com_2", 
		"URL=http://ocsp.digicert.com/", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/ocsp-response", 
		"Referer=", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/ocsp-request", 
		"BodyBinary=0Q0O0M0K0I0\t\\x06\\x05+\\x0E\\x03\\x02\\x1A\\x05\\x00\\x04\\x14t\\x02F\\xF2Z\\\\B\\x12 \\xB5\\xBD]v\t\\xA6\\xBA\\\\\\xA3G\\xDF\\x04\\x14$\\xF2.N\\x0F\\xBD\\xCA\\xF7>)U\\xCAr\\x8Di\\x87VD\\xE9z\\x02\\x10\\x06\\xBA\\xAD\\x9A4\\xCC\\x06O\\x8C\\xD0`k\\x99]\\x9C$", 
		LAST);

	web_custom_request("71f09ace-7b12-4c01-a4ec-546efd26d994", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/events/1/71f09ace-7b12-4c01-a4ec-546efd26d994", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t18.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":3,\"start_time\":\"2024-07-31T05:47:11.000+00:00\",\"end_time\":\"2024-07-31T07:02:19.007+00:00\",\"reason\":\"startup\",\"experiments\":{\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\""
		"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"pin-email-and-calendar-tabs-early-day-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"home-and-newtab-wallpapers-v1-rollout-global\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"recommend-add-ons-staff-pick-part-2\":{\"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-nimbus\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"60.1.1\",\"first_run_date\":\"2024-07-31+00:00\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"app_channel\":\"release\",\"os_version\":\"10.0\",\"app_display_version\":\"128.0.3\",\"app_build\":\"20240725162350\",\"architecture\":\""
		"x86_64\",\"locale\":\"en-US\",\"os\":\"Windows\",\"windows_build_number\":20348,\"client_id\":\"eba24bb8-b1b7-4cf8-820b-b08ed2ba5bb7\"},\"metrics\":{\"boolean\":{\"urlbar.pref_suggest_data_collection\":false,\"urlbar.pref_suggest_sponsored\":false,\"urlbar.pref_suggest_nonsponsored\":false,\"urlbar.pref_suggest_topsites\":true},\"uuid\":{\"legacy.telemetry.client_id\":\"822571c1-9c9d-4d99-8bbb-5171f4f2a291\"},\"quantity\":{\"urlbar.pref_max_results\":10}},\"events\":[{\"timestamp\":0,\"category\""
		":\"webcompatreporting\",\"name\":\"reason_dropdown\",\"extra\":{\"glean_timestamp\":\"1722404830726\",\"setting\":\"required\"}},{\"timestamp\":840,\"category\":\"nimbus_events\",\"name\":\"is_ready\",\"extra\":{\"glean_timestamp\":\"1722404831566\"}},{\"timestamp\":17077,\"category\":\"urlbar\",\"name\":\"abandonment\",\"extra\":{\"n_results\":\"10\",\"search_engine_default_id\":\"google-b-d\",\"results\":\"top_site,top_site,top_site,top_site,top_site,top_site,trending_search,trending_search,"
		"trending_search,trending_search\",\"sap\":\"urlbar_newtab\",\"abandonment_type\":\"blur\",\"search_mode\":\"\",\"groups\":\"top_site,top_site,top_site,top_site,top_site,top_site,trending_search,trending_search,trending_search,trending_search\",\"n_chars\":\"0\",\"glean_timestamp\":\"1722404847803\",\"interaction\":\"typed\",\"n_words\":\"0\"}}]}", 
		LAST);

	web_url("update.xml", 
		"URL=https://aus5.mozilla.org/update/6/Firefox/128.0.3/20240725162350/WINNT_x86_64-msvc-x64/en-US/release/Windows_NT%252010.0.0.0.20348.887%2520(x64)/ISET%3ASSE4_2%2CMEM%3A16196/default/default/update.xml?force=1", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_custom_request("4ce296cf-c197-441e-934c-21977eaf5bfc", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/4ce296cf-c197-441e-934c-21977eaf5bfc", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t20.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":5,\"start_time\":\"2024-07-31T05:47:12.000+00:00\",\"end_time\":\"2024-07-31T07:02:19.019+00:00\",\"reason\":\"dirty_startup\",\"experiments\":{\"home-and-newtab-wallpapers-v1-rollout-global\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},"
		"\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"pin-email-and-calendar-tabs-early-day-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\""
		"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"recommend-add-ons-staff-pick-part-2\":{\"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\""
		"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"60.1.1\",\"windows_build_number\":20348,\"os\":\"Windows\",\"os_version\":\"10.0\",\"app_build\":\"20240725162350\",\"app_channel\":\"release\",\"architecture\":\"x86_64\",\"locale\":\"en-US\",\"app_display_version\":\"128.0.3\",\"client_id\":\""
		"eba24bb8-b1b7-4cf8-820b-b08ed2ba5bb7\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2024-07-31+00:00\"},\"metrics\":{\"counter\":{\"browser.engagement.active_ticks\":2},\"labeled_counter\":{\"glean.validation.pings_submitted\":{\"baseline\":1,\"events\":1}},\"uuid\":{\"legacy.telemetry.client_id\":\"822571c1-9c9d-4d99-8bbb-5171f4f2a291\"}}}", 
		LAST);

	web_custom_request("1c367b1e-4584-45be-85b7-e58717654e6e", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/use-counters/1/1c367b1e-4584-45be-85b7-e58717654e6e", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":3,\"start_time\":\"2024-07-31T05:37:11.000+00:00\",\"end_time\":\"2024-07-31T06:04:30.915+00:00\",\"reason\":\"app_shutdown_confirmed\",\"experiments\":{\"home-and-newtab-wallpapers-v1-rollout-global\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\""
		"nimbus-nimbus\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"pin-email-and-calendar-tabs-early-day-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"recommend-add-ons-staff-pick-part-2\":{\"branch\":\""
		"treatment-b\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"60.1.1\",\"client_id\":\"eba24bb8-b1b7-4cf8-820b-b08ed2ba5bb7\",\"first_run_date\":\"2024-07-31+00:00\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"app_display_version\":\"128.0.3\",\"architecture\":\"x86_64\",\"app_build\":\"20240725162350\","
		"\"app_channel\":\"release\",\"locale\":\"en-US\",\"os\":\"Windows\",\"os_version\":\"10.0\",\"windows_build_number\":20348},\"metrics\":{\"counter\":{\"use.counter.css.doc.css_border_right\":2,\"use.counter.css.doc.css_left\":2,\"use.counter.css.doc.css_border\":2,\"use.counter.css.doc.css_font_family\":2,\"use.counter.css.doc.css_border_bottom\":1,\"use.counter.css.doc.css_list_style\":2,\"use.counter.css.doc.css_float\":2,\"use.counter.css.doc.css_border_radius\":2,\""
		"use.counter.css.doc.css_margin\":2,\"use.counter.css.doc.css_margin_bottom\":2,\"use.counter.css.doc.css_color\":2,\"use.counter.css.doc.css_font_size\":2,\"use.counter.css.doc.css_margin_left\":2,\"use.counter.css.doc.css_padding_right\":2,\"use.counter.css.doc.css_height\":2,\"use.counter.css.doc.css_margin_top\":2,\"use.counter.css.doc.css_overflow\":2,\"use.counter.css.doc.css_padding_top\":2,\"use.counter.css.doc.css_position\":2,\"use.counter.css.doc.css_padding_bottom\":2,\""
		"use.counter.css.doc.css_margin_right\":2,\"use.counter.css.doc.css_width\":2,\"use.counter.css.doc.css_clear\":2,\"use.counter.css.doc.css_font_weight\":2,\"use.counter.css.doc.css_box_shadow\":2,\"use.counter.css.doc.css_padding\":2,\"use.counter.css.doc.css_display\":2,\"use.counter.css.doc.css_padding_left\":2,\"use.counter.css.doc.css_transition_duration\":2,\"use.counter.css.doc.css_background_color\":2,\"use.counter.css.doc.css_text_decoration\":2,\"use.counter.css.doc.css_z_index\":1,\""
		"use.counter.css.doc.css_animation\":1,\"use.counter.css.doc.css_text_align\":2,\"use.counter.content_documents_destroyed\":2,\"use.counter.css.doc.css_line_height\":2,\"use.counter.css.doc.css_cursor\":2}}}", 
		LAST);

	web_custom_request("e1b0e551-0be7-4492-afe3-02ac8bf96209", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/newtab/1/e1b0e551-0be7-4492-afe3-02ac8bf96209", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t22.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":7,\"start_time\":\"2024-07-31T05:47:11.000+00:00\",\"end_time\":\"2024-07-31T07:02:19.123+00:00\",\"reason\":\"component_init\"},\"client_info\":{\"telemetry_sdk_build\":\"60.1.1\",\"app_channel\":\"release\",\"app_display_version\":\"128.0.3\",\"locale\":\"en-US\",\"os\":\"Windows\",\"architecture\":\"x86_64\",\"os_version\":\"10.0\",\"app_build\":\"20240725162350\",\"first_run_date\":\"2024-07-31+00:00\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"client_id\":\""
		"eba24bb8-b1b7-4cf8-820b-b08ed2ba5bb7\",\"windows_build_number\":20348},\"metrics\":{\"string\":{\"newtab.locale\":\"en-US\",\"newtab.homepage_category\":\"enabled\",\"newtab.newtab_category\":\"enabled\"},\"string_list\":{\"newtab.blocked_sponsors\":[]},\"quantity\":{\"topsites.rows\":1},\"boolean\":{\"topsites.enabled\":true,\"topsites.sponsored_enabled\":true,\"newtab.weather_enabled\":true,\"newtab.search.enabled\":true,\"pocket.sponsored_stories_enabled\":true,\"pocket.is_signed_in\":false,\""
		"pocket.enabled\":true}},\"events\":[{\"timestamp\":0,\"category\":\"newtab\",\"name\":\"opened\",\"extra\":{\"glean_timestamp\":\"1722404831138\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\",\"source\":\"about:home\"}},{\"timestamp\":94,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"glean_timestamp\":\"1722404831232\",\"is_sponsored\":\"false\",\"position\":\"6\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\"}},{\"timestamp\":95,\"category\":\""
		"topsites\",\"name\":\"impression\",\"extra\":{\"is_sponsored\":\"false\",\"position\":\"1\",\"glean_timestamp\":\"1722404831233\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\"}},{\"timestamp\":95,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"position\":\"0\",\"is_sponsored\":\"false\",\"glean_timestamp\":\"1722404831233\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\"}},{\"timestamp\":95,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":"
		"{\"is_sponsored\":\"false\",\"position\":\"7\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\",\"glean_timestamp\":\"1722404831233\"}},{\"timestamp\":96,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"glean_timestamp\":\"1722404831234\",\"is_sponsored\":\"false\",\"position\":\"5\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\"}},{\"timestamp\":96,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"position\":\"3\",\"glean_timestamp\":\""
		"1722404831234\",\"is_sponsored\":\"false\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\"}},{\"timestamp\":96,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"glean_timestamp\":\"1722404831234\",\"position\":\"4\",\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\",\"is_sponsored\":\"false\"}},{\"timestamp\":96,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"position\":\"2\",\"glean_timestamp\":\"1722404831234\",\"is_sponsored\":\"false\",\""
		"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\"}},{\"timestamp\":423,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"newtab_visit_id\":\"{843f23d9-d1ac-4023-921d-097f476493ba}\",\"position\":\"5\",\"glean_timestamp\":\"1722404831561\",\"is_sponsored\":\"false\"}},{\"timestamp\":480,\"category\":\"topsites\",\"name\":\"impression\",\"extra\":{\"is_sponsored\":\"true\",\"advertiser_name\":\"amazon\",\"tile_id\":\"74357\",\"position\":\"0\",\"newtab_visit_id\":\""
		"{843f23d9-d1ac-4023-921d-097f476493ba}\",\"glean_timestamp\":\"1722404831618\"}}]}", 
		LAST);

	web_custom_request("63589c42-b70f-45d3-8393-c8dbd7b51643", 
		"URL=https://incoming.telemetry.mozilla.org/submit/firefox-desktop/baseline/1/63589c42-b70f-45d3-8393-c8dbd7b51643", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t23.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=utf-8", 
		"Body={\"ping_info\":{\"seq\":6,\"start_time\":\"2024-07-31T07:02:19.000+00:00\",\"end_time\":\"2024-07-31T07:02:19.201+00:00\",\"reason\":\"active\",\"experiments\":{\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"pin-email-and-calendar-tabs-early-day-user\":{\"branch\":\"treatment-a\",\"extra\":{\"type\":\""
		"nimbus-nimbus\"}},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"ech-roll-out\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"extra\":{\"type\":\""
		"nimbus-rollout\"}},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"phc-rollout\":{\"branch\":\"rollout\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"extra\":{\"type\":\"nimbus-rollout\"}},\"recommend-add-ons-staff-pick-part-2\":{\"branch\":\"treatment-b\",\"extra\":{\"type\":\"nimbus-nimbus\"}},\"home-and-newtab-wallpapers-v1-rollout-global\":{\"branch\":\"control\","
		"\"extra\":{\"type\":\"nimbus-rollout\"}},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"extra\":{\"type\":\"nimbus-rollout\"}}}},\"client_info\":{\"telemetry_sdk_build\":\"60.1.1\",\"os\":\"Windows\",\"app_channel\":\"release\",\"architecture\":\"x86_64\",\"locale\":\"en-US\",\"app_build\":\"20240725162350\",\"os_version\":\"10.0\",\"app_display_version\":\"128.0.3\",\"build_date\":\"1970-01-01T00:00:00+00:00\",\"first_run_date\":\"2024-07-31+00"
		":00\",\"windows_build_number\":20348,\"client_id\":\"eba24bb8-b1b7-4cf8-820b-b08ed2ba5bb7\"},\"metrics\":{\"labeled_counter\":{\"glean.validation.pings_submitted\":{\"baseline\":1,\"newtab\":1}},\"uuid\":{\"legacy.telemetry.client_id\":\"822571c1-9c9d-4d99-8bbb-5171f4f2a291\"},\"counter\":{\"browser.engagement.uri_count\":1}}}", 
		LAST);

	lr_think_time(14);

	lr_start_transaction("TR02_StaffLogin");

	web_url("staff_login.php", 
		"URL=http://localhost/banking/staff_login.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=../favicon.ico", ENDITEM, 
		LAST);

	lr_end_transaction("TR02_StaffLogin",LR_AUTO);

	lr_think_time(38);

	lr_start_transaction("TR03_Login");

	web_custom_request("20240725162350", 
		"URL=https://incoming.telemetry.mozilla.org/submit/telemetry/a49c6ff7-0d12-4d6a-8c94-8ee75822187c/event/Firefox/128.0.3/release/20240725162350?v=4", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"BodyBinary={\"type\":\"event\",\"id\":\"a49c6ff7-0d12-4d6a-8c94-8ee75822187c\",\"creationDate\":\"2024-07-31T06:04:31.076Z\",\"version\":4,\"application\":{\"architecture\":\"x86-64\",\"buildId\":\"20240725162350\",\"name\":\"Firefox\",\"version\":\"128.0.3\",\"displayVersion\":\"128.0.3\",\"vendor\":\"Mozilla\",\"platformVersion\":\"128.0.3\",\"xpcomAbi\":\"x86_64-msvc\",\"channel\":\"release\"},\"payload\":{\"reason\":\"shutdown\",\"processStartTimestamp\":1722404820000,\"sessionId\":\""
		"89066759-a4ea-4f62-ae22-b071c7fddde5\",\"subsessionId\":\"f31b745b-f89d-4979-8675-545f6e0bee2a\",\"lostEventsCount\":0,\"events\":{\"parent\":[[423,\"session_restore\",\"backup_can_be_loaded\",\"session_file\",null,{\"can_load\":\"true\",\"path_key\":\"clean\",\"loadfail_reason\":\"N/A\"}],[423,\"session_restore\",\"backup_can_be_loaded\",\"session_file\",null,{\"can_load\":\"true\",\"path_key\":\"clean\",\"loadfail_reason\":\"N/A\"}],[423,\"session_restore\",\"shutdown_success\",\""
		"session_startup\",null,{\"shutdown_ok\":\"false\",\"shutdown_reason\":\"N/A\"}],[1345,\"doh\",\"state\",\"rollback\",\"null\"],[1892,\"upgrade_dialog\",\"trigger\",\"reason\",\"not-major\"],[1041095,\"doh\",\"state\",\"shutdown\",\"null\"]]}},\"clientId\":\"822571c1-9c9d-4d99-8bbb-5171f4f2a291\",\"environment\":{\"build\":{\"applicationId\":\"{ec8030f7-c20a-464f-9b0e-13a3a9e97384}\",\"applicationName\":\"Firefox\",\"architecture\":\"x86-64\",\"buildId\":\"20240725162350\",\"version\":\"128.0.3\","
		"\"vendor\":\"Mozilla\",\"displayVersion\":\"128.0.3\",\"platformVersion\":\"128.0.3\",\"xpcomAbi\":\"x86_64-msvc\",\"updaterAvailable\":true},\"partner\":{\"distributionId\":null,\"distributionVersion\":null,\"partnerId\":null,\"distributor\":null,\"distributorChannel\":null,\"partnerNames\":[]},\"system\":{\"memoryMB\":16196,\"virtualMaxMB\":134217728,\"cpu\":{\"isWindowsSMode\":false,\"count\":4,\"cores\":2,\"vendor\":\"GenuineIntel\",\"name\":\"Intel(R) Xeon(R) Platinum 8259CL CPU @ 2.50GHz\","
		"\"family\":6,\"model\":85,\"stepping\":7,\"l2cacheKB\":1024,\"l3cacheKB\":36608,\"speedMHz\":2500,\"extensions\":[\"hasMMX\",\"hasSSE\",\"hasSSE2\",\"hasSSE3\",\"hasSSSE3\",\"hasSSE4_1\",\"hasSSE4_2\",\"hasAVX\",\"hasAVX2\",\"hasAES\"]},\"os\":{\"installYear\":2022,\"hasSuperfetch\":true,\"hasPrefetch\":false,\"name\":\"Windows_NT\",\"version\":\"10.0\",\"locale\":\"en-US\",\"servicePackMajor\":0,\"servicePackMinor\":0,\"windowsBuildNumber\":20348,\"windowsUBR\":887},\"hdd\":{\"binary\":{\"model\""
		":\"NVMe Amazon Elastic B\",\"revision\":\"1.0\",\"type\":\"HDD\"},\"profile\":{\"model\":\"NVMe Amazon Elastic B\",\"revision\":\"1.0\",\"type\":\"HDD\"},\"system\":{\"model\":\"NVMe Amazon Elastic B\",\"revision\":\"1.0\",\"type\":\"HDD\"}},\"gfx\":{\"D2DEnabled\":false,\"DWriteEnabled\":true,\"ContentBackend\":\"Skia\",\"Headless\":false,\"EmbeddedInFirefoxReality\":false,\"TargetFrameRate\":32,\"adapters\":[{\"description\":\"Microsoft Remote Display Adapter\",\"vendorID\":\"0x000d\",\""
		"deviceID\":\"0x000d\",\"subsysID\":\"0000000d\",\"RAM\":0,\"driver\":\"Unknown\",\"driverVendor\":null,\"driverVersion\":null,\"driverDate\":null,\"GPUActive\":true}],\"monitors\":[{\"screenWidth\":1280,\"screenHeight\":544,\"refreshRate\":32,\"pseudoDisplay\":false}],\"features\":{\"compositor\":\"webrender_software\",\"hwCompositing\":{\"status\":\"available\"},\"gpuProcess\":{\"status\":\"available\"},\"webrender\":{\"status\":\"blocklisted:FEATURE_FAILURE_UNKNOWN_DEVICE_VENDOR\"},\""
		"wrCompositor\":{\"status\":\"unavailable:FEATURE_FAILURE_DCOMP_NOT_ANGLE\"},\"openglCompositing\":{\"status\":\"unused\"},\"omtp\":{\"status\":\"unused\"},\"d3d11\":{\"status\":\"blocklisted:FEATURE_FAILURE_UNKNOWN_DEVICE_VENDOR\"},\"d2d\":{\"status\":\"unavailable:FEATURE_FAILURE_D2D_D3D11_COMP\",\"version\":\"1.1\"}}},\"appleModelId\":null,\"hasWinPackageId\":false,\"sec\":{\"antivirus\":null,\"antispyware\":null,\"firewall\":null},\"isWow64\":false,\"isWowARM64\":false},\"settings\":{\""
		"blocklistEnabled\":true,\"e10sEnabled\":true,\"e10sMultiProcesses\":8,\"fissionEnabled\":true,\"telemetryEnabled\":false,\"locale\":\"en-US\",\"intl\":{\"requestedLocales\":[\"en-US\"],\"availableLocales\":[\"en-US\"],\"appLocales\":[\"en-US\"],\"systemLocales\":[\"en-US\"],\"regionalPrefsLocales\":[\"en-US\"],\"acceptLanguages\":[\"en-US\",\"en\"]},\"update\":{\"channel\":\"release\",\"enabled\":true,\"autoDownload\":true,\"background\":true},\"userPrefs\":{\"browser.search.region\":\"IN\",\""
		"browser.search.widget.inNavBar\":false,\"browser.urlbar.autoFill\":true,\"browser.urlbar.autoFill.adaptiveHistory.enabled\":false,\"browser.urlbar.dnsResolveSingleWordsAfterSearch\":0,\"browser.urlbar.quicksuggest.dataCollection.enabled\":false,\"browser.urlbar.suggest.quicksuggest.nonsponsored\":false,\"browser.urlbar.suggest.quicksuggest.sponsored\":false,\"media.gmp-gmpopenh264.lastInstallStart\":1722402463,\"media.gmp-gmpopenh264.lastDownload\":1722402463,\"media.gmp-gmpopenh264.lastUpdate\""
		":1722402463,\"media.gmp-widevinecdm.lastInstallStart\":1722402463,\"media.gmp-widevinecdm.lastDownload\":1722402464,\"media.gmp-widevinecdm.lastUpdate\":1722402465,\"media.gmp-manager.lastCheck\":1722403476,\"media.gmp-manager.lastEmptyCheck\":1722403476,\"network.trr.strict_native_fallback\":false,\"widget.content.gtk-high-contrast.enabled\":true},\"sandbox\":{\"effectiveContentProcessLevel\":7,\"contentWin32kLockdownState\":15},\"launcherProcessState\":0,\"addonCompatibilityCheckEnabled\":true,"
		"\"isDefaultBrowser\":true,\"attribution\":{\"campaign\":\"%2528not%2Bset%2529\",\"content\":\"%2528not%2Bset%2529\",\"dlsource\":\"mozorg\",\"dltoken\":\"f8162e47-451d-4534-80e8-3cd383d164ec\",\"experiment\":\"%2528not%2Bset%2529\",\"medium\":\"%2528direct%2529\",\"source\":\"%2528not%2Bset%2529\",\"ua\":\"chrome\",\"variation\":\"%2528not%2Bset%2529\"},\"defaultSearchEngine\":\"google-b-d\",\"defaultSearchEngineData\":{\"loadPath\":\"[app]google@search.mozilla.org\",\"name\":\"Google\",\"origin\""
		":\"default\",\"submissionURL\":\"https://www.google.com/search?client=firefox-b-d&q=\"}},\"profile\":{\"creationDate\":19935,\"firstUseDate\":19935},\"addons\":{\"activeAddons\":{\"formautofill@mozilla.org\":{\"version\":\"1.0.1\",\"scope\":1,\"type\":\"extension\",\"updateDay\":19929,\"isSystem\":true,\"isWebExtension\":true,\"multiprocessCompatible\":true,\"blocklisted\":false,\"description\":null,\"name\":\"Form Autofill\",\"userDisabled\":false,\"appDisabled\":false,\"foreignInstall\":false,\""
		"hasBinaryComponents\":false,\"installDay\":19929,\"quarantineIgnoredByApp\":true,\"quarantineIgnoredByUser\":false},\"pictureinpicture@mozilla.org\":{\"version\":\"1.0.0\",\"scope\":1,\"type\":\"extension\",\"updateDay\":19929,\"isSystem\":true,\"isWebExtension\":true,\"multiprocessCompatible\":true,\"blocklisted\":false,\"description\":\"Fixes for web compatibility with Picture-in-Picture\",\"name\":\"Picture-In-Picture\",\"userDisabled\":false,\"appDisabled\":false,\"foreignInstall\":false,\""
		"hasBinaryComponents\":false,\"installDay\":19929,\"quarantineIgnoredByApp\":true,\"quarantineIgnoredByUser\":false},\"webcompat@mozilla.org\":{\"version\":\"128.3.0\",\"scope\":1,\"type\":\"extension\",\"updateDay\":19929,\"isSystem\":true,\"isWebExtension\":true,\"multiprocessCompatible\":true,\"blocklisted\":false,\"description\":\"Urgent post-release fixes for web compatibility.\",\"name\":\"Web Compatibility Interventions\",\"userDisabled\":false,\"appDisabled\":false,\"foreignInstall\":false,"
		"\"hasBinaryComponents\":false,\"installDay\":19929,\"quarantineIgnoredByApp\":true,\"quarantineIgnoredByUser\":false}},\"theme\":{\"id\":\"default-theme@mozilla.org\",\"blocklisted\":false,\"description\":\"Follow the operating system setting for buttons, menus, and windows.\",\"name\":\"System theme \\xE2\\x80\\x94 auto\",\"userDisabled\":false,\"appDisabled\":false,\"version\":\"1.3\",\"scope\":4,\"foreignInstall\":false,\"hasBinaryComponents\":false,\"installDay\":19935,\"updateDay\":19935},\""
		"activeGMPlugins\":{\"gmp-gmpopenh264\":{\"version\":\"2.3.2\",\"userDisabled\":false,\"applyBackgroundUpdates\":1},\"gmp-widevinecdm\":{\"version\":\"4.10.2710.0\",\"userDisabled\":false,\"applyBackgroundUpdates\":1}}},\"experiments\":{\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"type\":\"nimbus-nimbus\"},\"recommend-add-ons-staff-pick-part-2\":{\"branch\":\"treatment-b\",\"type\":\"nimbus-nimbus\"},\"pin-email-and-calendar-tabs-early-day-user\":{\"branch\":\""
		"treatment-a\",\"type\":\"nimbus-nimbus\"},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"type\":\"nimbus-rollout\"},\"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"type\":\"nimbus-rollout\"},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"type\":\"nimbus-rollout\"},\"ech-roll-out\":{\"branch\":\"rollout\",\"type\":\"nimbus-rollout\"},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"type\":\""
		"nimbus-rollout\"},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"type\":\"nimbus-rollout\"},\"phc-rollout\":{\"branch\":\"rollout\",\"type\":\"nimbus-rollout\"},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"type\":\"nimbus-rollout\"},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"type\":\"nimbus-rollout\"},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"type\":\"nimbus-rollout\"},\""
		"home-and-newtab-wallpapers-v1-rollout-global\":{\"branch\":\"control\",\"type\":\"nimbus-rollout\"}}}}", 
		LAST);

	web_custom_request("20240725162350_2", 
		"URL=https://incoming.telemetry.mozilla.org/submit/telemetry/d4d24ee8-5d0e-4afd-87b4-c78bc7786cac/main/Firefox/128.0.3/release/20240725162350?v=4", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/plain", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"ContentEncoding=gzip", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"BodyBinary={\"type\":\"main\",\"id\":\"d4d24ee8-5d0e-4afd-87b4-c78bc7786cac\",\"creationDate\":\"2024-07-31T06:04:31.091Z\",\"version\":4,\"application\":{\"architecture\":\"x86-64\",\"buildId\":\"20240725162350\",\"name\":\"Firefox\",\"version\":\"128.0.3\",\"displayVersion\":\"128.0.3\",\"vendor\":\"Mozilla\",\"platformVersion\":\"128.0.3\",\"xpcomAbi\":\"x86_64-msvc\",\"channel\":\"release\"},\"payload\":{\"ver\":4,\"simpleMeasurements\":{\"totalTime\":1041,\"start\":17,\"main\":126,\""
		"selectProfile\":132,\"afterProfileLocked\":133,\"startupCrashDetectionBegin\":323,\"startupCrashDetectionEnd\":33609,\"firstPaint\":782,\"firstPaint2\":753,\"sessionRestoreInit\":388,\"sessionRestored\":911,\"createTopLevelWindow\":193,\"quitApplication\":1040954,\"profileBeforeChange\":1041128,\"blankWindowShown\":324,\"AMI_startup_begin\":332,\"XPI_startup_begin\":342,\"XPI_bootstrap_addons_begin\":350,\"XPI_bootstrap_addons_end\":361,\"XPI_startup_end\":362,\"AMI_startup_end\":362,\""
		"XPI_finalUIStartup\":388,\"sessionRestoreInitialized\":392,\"delayedStartupStarted\":786,\"delayedStartupFinished\":862,\"sessionRestoreRestoring\":890,\"startupInterrupted\":0,\"debuggerAttached\":0,\"startupWindowVisibleReadBytes\":1087891,\"startupWindowVisibleWriteBytes\":78529,\"startupSessionRestoreReadBytes\":1258729,\"startupSessionRestoreWriteBytes\":108645,\"activeTicks\":3},\"processes\":{\"parent\":{\"scalars\":{\"browser.searchinit.insecure_opensearch_engine_count\":0,\""
		"browser.searchinit.secure_opensearch_engine_count\":0,\"browser.backup.places_size\":5240,\"browser.backup.cookies_size\":100,\"browser.engagement.max_concurrent_tab_count\":1,\"browser.backup.preferences_size\":384,\"browser.backup.credentials_data_size\":300,\"browser.backup.favicons_size\":5240,\"contentblocking.fingerprinting_blocking_enabled\":true,\"browser.backup.security_data_size\":231,\"browser.backup.session_store_size\":120,\"security.https_only_mode_enabled_pbm\":0,\""
		"browser.engagement.max_concurrent_tab_pinned_count\":0,\"os.environment.is_admin_without_uac\":false,\"a11y.use_system_colors\":true,\"contentblocking.cryptomining_blocking_enabled\":true,\"os.environment.allowed_app_sources\":\"Anywhere\",\"browser.startup.abouthome_cache_result\":6,\"browser.searchinit.insecure_opensearch_update_count\":0,\"security.https_only_mode_enabled\":0,\"browser.backup.misc_data_size\":3408,\"os.environment.launch_method\":\"Taskbar\",\"contentblocking.category\":0,\""
		"browser.searchinit.secure_opensearch_update_count\":0,\"startup.seconds_since_last_os_restart\":5513,\"security.global_privacy_control_enabled\":0,\"urlbar.zeroprefix.exposure\":1,\"browser.engagement.active_ticks\":3,\"browser.backup.form_history_size\":260,\"networking.nss_initialization\":15,\"timestamps.first_paint\":782,\"gfx.supports_hdr\":false,\"datasanitization.session_permission_exceptions\":0,\"startup.profile_selection_reason\":\"default\",\"dom.contentprocess.os_priority_raised\":7,\""
		"browser.engagement.session_time_including_suspend\":1041133,\"browser.backup.storage_sync_size\":0,\"networking.loading_certs_task\":14,\"browser.backup.session_store_backups_directory_size\":40,\"browser.startup.abouthome_cache_shutdownwrite\":false,\"browser.backup.browser_extension_data_size\":0,\"formautofill.availability\":false,\"startup.profile_database_version\":\"2\",\"urlbar.zeroprefix.abandonment\":1,\"dom.contentprocess.os_priority_lowered\":4,\"policies.is_enterprise\":false,\""
		"browser.backup.prof_d_disk_space\":9600000,\"browser.backup.extensions_xpi_directory_size\":0,\"a11y.backplate\":true,\"urlbar.abandonment\":1,\"gfx.os_compositor\":false,\"browser.engagement.session_time_excluding_suspend\":1041133,\"startup.profile_count\":2,\"dom.contentprocess.os_priority_change_considered\":16,\"policies.count\":0,\"browser.backup.extensions_storage_size\":0,\"a11y.always_underline_links\":false,\"pictureinpicture.toggle_enabled\":true,\"startup.is_cold\":false,\""
		"power.total_cpu_time_ms\":12447,\"browser.engagement.max_concurrent_window_count\":1,\"os.environment.is_taskbar_pinned_private\":false,\"browser.backup.extensions_json_size\":31,\"timestamps.about_home_topsites_first_paint\":1353,\"power.total_thread_wakeups\":33647,\"widget.dark_mode\":false,\"timestamps.first_paint_two\":753,\"os.environment.is_taskbar_pinned\":true,\"browser.engagement.profile_count\":1,\"networking.http3_enabled\":true},\"keyedScalars\":{\"os.environment.is_default_handler\":"
		"{\"mailto\":false,\".pdf\":true},\"power.cpu_time_per_process_type_ms\":{\"parent.inactive\":7045,\"parent.active\":5402},\"contextual.services.topsites.impression\":{\"newtab_1\":1},\"browser.search.data_transferred\":{\"sggt-google-b-d\":1451},\"a11y.theme\":{\"default\":false},\"browser.engagement.sessionrestore_interstitial\":{\"deferred_restore\":1},\"security.client_auth_cert_usage\":{\"sent\":0,\"requested\":0},\"networking.data_transferred_v3_kb\":{\"Y0_N1Sys\":32,\"Y2_N3Oth\":89},\""
		"telemetry.event_counts\":{\"doh#state#shutdown\":1,\"upgrade_dialog#trigger#reason\":1,\"session_restore#backup_can_be_loaded#session_file\":2,\"doh#state#rollback\":1,\"session_restore#shutdown_success#session_startup\":1},\"networking.data_transferred_per_content_type\":{\"text_other\":944,\"application_other\":4512,\"other\":960,\"text_plain\":14639,\"text_json\":16658,\"ocsp\":26680,\"text_html\":3878,\"text_javascript\":1451,\"image\":60879},\"power.wakeups_per_process_type\":{\""
		"parent.inactive\":23516,\"parent.active\":10131},\"browser.ui.toolbar_widgets\":{\"bookmark_pinned_pageaction-urlbar\":true,\"import-button_pinned_bookmarks-bar\":true,\"save-to-pocket-button_pinned_nav-bar-end\":true,\"fxa-toolbar-menu-button_pinned_nav-bar-end\":true,\"stop-reload-button_pinned_nav-bar-start\":true,\"firefox-view-button_pinned_tabs-bar\":true,\"downloads-button_pinned_nav-bar-end\":true,\"personal-bookmarks_pinned_bookmarks-bar\":true,\"menu-toolbar_pinned_off\":true,\""
		"tabbrowser-tabs_pinned_tabs-bar\":true,\"titlebar_pinned_off\":true,\"alltabs-button_pinned_tabs-bar\":true,\"new-tab-button_pinned_tabs-bar\":true,\"forward-button_pinned_nav-bar-start\":true,\"menubar-items_pinned_menu-bar\":true,\"back-button_pinned_nav-bar-start\":true,\"bookmarks-bar_pinned_newtab\":true,\"unified-extensions-button_pinned_nav-bar-end\":true},\"networking.speculative_connect_outcome\":{\"aborted_socket_limit\":21,\"successful\":46}}},\"content\":{\"histograms\":{\""
		"CYCLE_COLLECTOR_MAX_PAUSE\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":26,\"range\":[1,10000],\"values\":{\"0\":2,\"1\":5,\"2\":1,\"17\":1,\"20\":0}},\"GC_ZONE_COUNT\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":22,\"range\":[1,100],\"values\":{\"3\":0,\"4\":4,\"6\":1,\"7\":0}},\"GC_ZONES_COLLECTED\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":19,\"range\":[1,100],\"values\":{\"1\":0,\"2\":1,\"3\":1,\"4\":2,\"6\":1,\"7\":0}},\"GC_MS\":{\"bucket_count\":50,\"histogram_type\":0,\""
		"sum\":86,\"range\":[1,10000],\"values\":{\"10\":0,\"12\":1,\"14\":1,\"17\":1,\"20\":2,\"24\":0}},\"GC_IN_PROGRESS_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":300,\"range\":[1,10000],\"values\":{\"40\":0,\"48\":2,\"57\":2,\"68\":1,\"81\":0}},\"GC_BUDGET_WAS_INCREASED\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":22,\"1\":0}},\"GC_SLICE_WAS_LONG\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":22,\"1\":0}},\""
		"GC_MAX_PAUSE_MS_2\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":73,\"range\":[1,10000],\"values\":{\"6\":0,\"7\":1,\"10\":1,\"14\":1,\"20\":2,\"24\":0}},\"GC_PREPARE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":2,\"range\":[1,1000],\"values\":{\"0\":3,\"1\":2,\"2\":0}},\"GC_MARK_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":55,\"range\":[1,10000],\"values\":{\"3\":0,\"4\":1,\"8\":1,\"12\":1,\"14\":2,\"17\":0}},\"GC_SWEEP_MS\":{\"bucket_count\":50,\"histogram_type\":0,\""
		"sum\":15,\"range\":[1,10000],\"values\":{\"0\":0,\"1\":1,\"2\":1,\"3\":1,\"4\":1,\"5\":1,\"6\":0}},\"GC_COMPACT_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":4,\"range\":[1,10000],\"values\":{\"3\":0,\"4\":1,\"5\":0}},\"GC_SLICE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":82,\"range\":[1,10000],\"values\":{\"0\":14,\"1\":1,\"4\":2,\"7\":1,\"10\":1,\"14\":1,\"20\":2,\"24\":0}},\"GC_MMU_50\":{\"bucket_count\":20,\"histogram_type\":1,\"sum\":323,\"range\":[1,100],\"values\":{\"51"
		"\":0,\"56\":2,\"62\":2,\"73\":1,\"78\":0}},\"GC_MINOR_US\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":27727,\"range\":[1,1000000],\"values\":{\"1\":0,\"2\":2,\"3\":3,\"13\":2,\"17\":1,\"53\":1,\"130\":3,\"168\":1,\"247\":1,\"320\":1,\"364\":2,\"471\":1,\"536\":4,\"791\":2,\"1026\":1,\"1330\":1,\"1514\":1,\"2545\":2,\"3300\":2,\"4279\":1,\"4872\":0}},\"GC_TIME_BETWEEN_SLICES_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":205,\"range\":[1,2000],\"values\":{\"0\":4,\"5\":1,\"15\":6,\""
		"17\":5,\"19\":1,\"22\":0}},\"GC_SLICE_COUNT\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":22,\"range\":[1,200],\"values\":{\"2\":0,\"3\":1,\"4\":2,\"5\":1,\"6\":1,\"7\":0}},\"DESERIALIZE_BYTES\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":3348688,\"range\":[16,2147483646],\"values\":{\"0\":0,\"16\":132,\"23\":35,\"41\":2,\"61\":8,\"74\":12,\"90\":1,\"109\":7,\"132\":6,\"194\":16,\"344\":1,\"416\":12,\"503\":7,\"609\":3,\"737\":43,\"892\":12,\"1080\":6,\"1307\":1,\"1915\":3,\"2318\":1,"
		"\"3395\":4,\"4973\":4,\"6019\":1,\"15625\":1,\"22886\":2,\"27698\":22,\"105331\":6,\"400557\":4,\"484771\":0}},\"DESERIALIZE_ITEMS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":34552,\"range\":[1,2147483646],\"values\":{\"0\":0,\"1\":167,\"3\":42,\"5\":10,\"8\":4,\"12\":2,\"19\":22,\"30\":59,\"47\":7,\"73\":2,\"113\":8,\"176\":15,\"274\":1,\"662\":3,\"1029\":1,\"1599\":3,\"2485\":6,\"3862\":0}},\"DESERIALIZE_US\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":19123,\"range\":[1,150000000"
		"],\"values\":{\"0\":29,\"1\":50,\"2\":21,\"3\":24,\"4\":25,\"5\":12,\"6\":12,\"7\":12,\"8\":13,\"10\":15,\"12\":12,\"14\":13,\"17\":12,\"20\":22,\"24\":11,\"29\":9,\"35\":5,\"42\":3,\"50\":3,\"60\":7,\"72\":3,\"87\":7,\"105\":1,\"126\":2,\"151\":4,\"182\":3,\"219\":2,\"263\":9,\"316\":1,\"457\":3,\"549\":3,\"660\":1,\"1146\":1,\"1378\":1,\"2879\":1,\"3461\":0}},\"GEOLOCATION_ERROR\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\""
		"MEMORY_RESIDENT_FAST\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":2920908,\"range\":[32768,16777216],\"values\":{\"0\":51,\"85139\":8,\"90735\":9,\"96699\":0}},\"MEMORY_UNIQUE\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":1013112,\"range\":[32768,16777216],\"values\":{\"0\":51,\"37217\":9,\"39663\":8,\"42270\":0}},\"MEMORY_JS_GC_HEAP\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":192512,\"range\":[1024,16777216],\"values\":{\"0\":0,\"1024\":51,\"8022\":16,\"8848\":1,\"9292\":0"
		"}},\"GHOST_WINDOWS\":{\"bucket_count\":32,\"histogram_type\":0,\"sum\":0,\"range\":[1,128],\"values\":{\"0\":68,\"1\":0}},\"MEMORY_PHC_SLOP\":{\"bucket_count\":48,\"histogram_type\":0,\"sum\":1813808,\"range\":[4096,8388608],\"values\":{\"0\":17,\"7948\":34,\"68562\":1,\"80923\":16,\"95512\":0}},\"MEMORY_PHC_SLOTS_ALLOCATED\":{\"bucket_count\":64,\"histogram_type\":0,\"sum\":452,\"range\":[1,16384],\"values\":{\"0\":0,\"1\":17,\"2\":34,\"20\":17,\"23\":0}},\"MEMORY_PHC_SLOTS_FREED\":{\""
		"bucket_count\":64,\"histogram_type\":0,\"sum\":824,\"range\":[1,16384],\"values\":{\"0\":4,\"1\":30,\"2\":17,\"40\":9,\"46\":8,\"53\":0}},\"AVIF_COLR\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"AVIF_PASP\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"AVIF_MAJOR_BRAND\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"AVIF_SEQUENCE\":"
		"{\"bucket_count\":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"AVIF_A1LX\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"AVIF_A1OP\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"AVIF_CLAP\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"AVIF_GRID\":{\"bucket_count\""
		":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"AVIF_IPRO\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"AVIF_LSEL\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":2,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":0}},\"SCRIPT_PRELOADER_REQUESTS\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":30,\"range\":[1,50],\"values\":{\"0\":69,\"2\":15,\"3\":0}},\""
		"FX_ABOUTHOME_CACHE_CONSTRUCTION\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":285,\"range\":[1,10000],\"values\":{\"29\":0,\"31\":1,\"37\":1,\"43\":1,\"161\":1,\"174\":0}},\"INPUT_EVENT_RESPONSE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":719,\"range\":[1,10000],\"values\":{\"0\":8,\"1\":5,\"5\":2,\"8\":2,\"10\":3,\"12\":1,\"14\":1,\"17\":3,\"24\":2,\"40\":4,\"160\":1,\"190\":1,\"226\":0}},\"INPUT_EVENT_RESPONSE_COALESCED_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":340"
		",\"range\":[1,10000],\"values\":{\"0\":7,\"1\":4,\"5\":1,\"8\":1,\"12\":1,\"17\":1,\"40\":1,\"57\":1,\"190\":1,\"226\":0}},\"MEDIA_SNIFFER_MP4_BRAND_PATTERN\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":20,\"range\":[1,50],\"values\":{\"9\":0,\"10\":2,\"11\":0}},\"MASTER_PASSWORD_ENABLED\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"CONTENT_PAINT_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":234,\"range\":[1,1000],\"values\":"
		"{\"0\":6,\"1\":37,\"2\":25,\"3\":8,\"4\":6,\"5\":4,\"6\":1,\"7\":2,\"9\":1,\"11\":2,\"12\":1,\"14\":1,\"16\":0}},\"TIME_TO_NON_BLANK_PAINT_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":410,\"range\":[1,100000],\"values\":{\"356\":0,\"395\":1,\"438\":0}},\"TIME_TO_FIRST_CONTENTFUL_PAINT_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":469,\"range\":[1,100000],\"values\":{\"395\":0,\"438\":1,\"486\":0}},\"TIME_TO_DOM_LOADING_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\""
		":117,\"range\":[1,50000],\"values\":{\"1\":0,\"2\":1,\"108\":1,\"119\":0}},\"TIME_TO_DOM_INTERACTIVE_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":175,\"range\":[1,50000],\"values\":{\"15\":0,\"17\":1,\"144\":1,\"158\":0}},\"TIME_TO_DOM_CONTENT_LOADED_START_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":183,\"range\":[1,50000],\"values\":{\"23\":0,\"25\":1,\"158\":1,\"174\":0}},\"TIME_TO_DOM_CONTENT_LOADED_END_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":446,\"range\""
		":[1,50000],\"values\":{\"50\":0,\"55\":1,\"374\":1,\"412\":0}},\"TIME_TO_DOM_COMPLETE_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":697,\"range\":[1,50000],\"values\":{\"131\":0,\"144\":1,\"500\":1,\"550\":0}},\"TIME_TO_LOAD_EVENT_START_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":697,\"range\":[1,50000],\"values\":{\"131\":0,\"144\":1,\"500\":1,\"550\":0}},\"TIME_TO_LOAD_EVENT_END_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":699,\"range\":[1,50000],\"values\":{\""
		"131\":0,\"144\":1,\"500\":1,\"550\":0}},\"PERF_REQUEST_ANIMATION_CALLBACK_NON_PAGELOAD_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":0,\"range\":[1,5000],\"values\":{\"0\":1,\"1\":0}},\"PERF_REQUEST_ANIMATION_CALLBACK_PAGELOAD_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":0,\"range\":[1,5000],\"values\":{\"0\":1,\"1\":0}},\"REL_PRELOAD_MISS_RATIO\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":14,\"range\":[1,50],\"values\":{\"0\":9,\"2\":7,\"3\":0}}},\"keyedHistograms\":{"
		"\"NETWORK_ASYNC_OPEN_CHILD_TO_TRANSACTION_PENDING_EXP_MS\":{\"0\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":1584,\"range\":[1,2000],\"values\":{\"2\":0,\"3\":3,\"6\":1,\"11\":1,\"296\":5,\"339\":0}}},\"NETWORK_RESPONSE_START_PARENT_TO_CONTENT_EXP_MS\":{\"0\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":134,\"range\":[1,2000],\"values\":{\"0\":1,\"1\":3,\"2\":1,\"9\":5,\"25\":2,\"29\":1,\"33\":0}}},\"NETWORK_RESPONSE_END_PARENT_TO_CONTENT_MS\":{\"0\":{\"bucket_count\":50,\""
		"histogram_type\":0,\"sum\":162,\"range\":[1,2000],\"values\":{\"0\":2,\"1\":2,\"3\":1,\"8\":1,\"15\":4,\"25\":1,\"29\":1,\"33\":1,\"38\":0}}}},\"scalars\":{\"telemetry.discarded.keyed_accumulations\":0,\"power.total_cpu_time_ms\":2942,\"telemetry.discarded.child_events\":0,\"telemetry.discarded.accumulations\":0,\"script.preloader.mainthread_recompile\":16,\"telemetry.discarded.scalar_actions\":0,\"power.total_thread_wakeups\":8631,\"telemetry.discarded.keyed_scalar_actions\":0,\""
		"networking.http3_enabled\":true},\"keyedScalars\":{\"power.cpu_time_per_process_type_ms\":{\"prealloc\":539,\"privilegedabout\":2403},\"power.wakeups_per_process_type\":{\"prealloc\":1707,\"privilegedabout\":6924}}},\"extension\":{\"histograms\":{\"CYCLE_COLLECTOR_MAX_PAUSE\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":2,\"range\":[1,10000],\"values\":{\"0\":6,\"2\":1,\"3\":0}},\"GC_ZONE_COUNT\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":34,\"range\":[1,100],\"values\":{\"5\":0,\"6\""
		":4,\"9\":1,\"11\":0}},\"GC_ZONES_COLLECTED\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":29,\"range\":[1,100],\"values\":{\"0\":0,\"1\":1,\"6\":3,\"9\":1,\"11\":0}},\"GC_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":39,\"range\":[1,10000],\"values\":{\"4\":0,\"5\":1,\"6\":2,\"10\":1,\"12\":1,\"14\":0}},\"GC_IN_PROGRESS_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":270,\"range\":[1,10000],\"values\":{\"34\":0,\"40\":1,\"48\":3,\"57\":1,\"68\":0}},\"GC_BUDGET_WAS_INCREASED\":"
		"{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":20,\"1\":0}},\"GC_SLICE_WAS_LONG\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":20,\"1\":0}},\"GC_MAX_PAUSE_MS_2\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":34,\"range\":[1,10000],\"values\":{\"4\":0,\"5\":1,\"6\":2,\"7\":1,\"10\":1,\"12\":0}},\"GC_PREPARE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":0,\"range\":[1,1000],\"values\":{\"0\":5,\"1\":0}},\""
		"GC_MARK_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":22,\"range\":[1,10000],\"values\":{\"2\":0,\"3\":1,\"4\":2,\"5\":1,\"6\":1,\"7\":0}},\"GC_SWEEP_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":8,\"range\":[1,10000],\"values\":{\"0\":0,\"1\":2,\"2\":3,\"3\":0}},\"GC_COMPACT_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":4,\"range\":[1,10000],\"values\":{\"3\":0,\"4\":1,\"5\":0}},\"GC_SLICE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":38,\"range\":[1,10000],\""
		"values\":{\"0\":14,\"4\":1,\"5\":1,\"6\":2,\"7\":1,\"10\":1,\"12\":0}},\"GC_MMU_50\":{\"bucket_count\":20,\"histogram_type\":1,\"sum\":415,\"range\":[1,100],\"values\":{\"67\":0,\"73\":1,\"78\":1,\"84\":2,\"89\":1,\"95\":0}},\"GC_MINOR_US\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":13516,\"range\":[1,1000000],\"values\":{\"1\":0,\"2\":1,\"3\":1,\"4\":1,\"10\":1,\"15\":1,\"536\":1,\"1168\":1,\"1514\":1,\"1724\":2,\"5548\":1,\"6317\":0}},\"GC_TIME_BETWEEN_SLICES_MS\":{\"bucket_count\":50,\""
		"histogram_type\":0,\"sum\":221,\"range\":[1,2000],\"values\":{\"0\":1,\"15\":12,\"17\":2,\"19\":0}},\"GC_SLICE_COUNT\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":20,\"range\":[1,200],\"values\":{\"2\":0,\"3\":1,\"4\":3,\"5\":1,\"6\":0}},\"DESERIALIZE_BYTES\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":1193144,\"range\":[16,2147483646],\"values\":{\"0\":0,\"16\":207,\"23\":8,\"34\":185,\"41\":13,\"50\":2,\"61\":2,\"74\":3,\"90\":1,\"109\":8,\"132\":1,\"194\":7,\"284\":6,\"416\":1,\""
		"503\":128,\"609\":78,\"737\":43,\"892\":11,\"1080\":5,\"1307\":4,\"1582\":8,\"1915\":5,\"2318\":8,\"2805\":7,\"3395\":4,\"4109\":10,\"4973\":6,\"6019\":4,\"7284\":6,\"8815\":8,\"10668\":5,\"12911\":1,\"15625\":1,\"18910\":3,\"27698\":1,\"40569\":1,\"49098\":1,\"400557\":1,\"484771\":0}},\"DESERIALIZE_ITEMS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":36565,\"range\":[1,2147483646],\"values\":{\"0\":0,\"1\":215,\"3\":210,\"5\":9,\"12\":213,\"19\":13,\"30\":48,\"47\":15,\"73\":11,\"113\":14,"
		"\"176\":11,\"274\":11,\"426\":11,\"662\":6,\"1029\":4,\"1599\":1,\"2485\":1,\"3862\":0}},\"DESERIALIZE_US\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":19372,\"range\":[1,150000000],\"values\":{\"0\":177,\"1\":159,\"2\":39,\"3\":12,\"4\":38,\"5\":40,\"6\":21,\"7\":21,\"8\":42,\"10\":40,\"12\":26,\"14\":28,\"17\":18,\"20\":27,\"24\":12,\"29\":6,\"35\":12,\"42\":6,\"50\":13,\"60\":9,\"72\":10,\"87\":5,\"105\":4,\"126\":3,\"151\":5,\"182\":3,\"219\":5,\"263\":2,\"316\":3,\"380\":2,\"457\":1,\""
		"660\":1,\"793\":1,\"1378\":1,\"2395\":1,\"2879\":0}},\"GEOLOCATION_ERROR\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"MEMORY_RESIDENT_FAST\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":844080,\"range\":[32768,16777216],\"values\":{\"45048\":0,\"48009\":17,\"51164\":0}},\"MEMORY_UNIQUE\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":260404,\"range\":[32768,16777216],\"values\":{\"0\":17,\"32768\":0}},\"MEMORY_JS_GC_HEAP\":{\""
		"bucket_count\":200,\"histogram_type\":0,\"sum\":104448,\"range\":[1024,16777216],\"values\":{\"5693\":0,\"5979\":17,\"6279\":0}},\"GHOST_WINDOWS\":{\"bucket_count\":32,\"histogram_type\":0,\"sum\":0,\"range\":[1,128],\"values\":{\"0\":17,\"1\":0}},\"MEMORY_PHC_SLOP\":{\"bucket_count\":48,\"histogram_type\":0,\"sum\":176320,\"range\":[4096,8388608],\"values\":{\"6734\":0,\"7948\":12,\"15424\":5,\"18205\":0}},\"MEMORY_PHC_SLOTS_ALLOCATED\":{\"bucket_count\":64,\"histogram_type\":0,\"sum\":44,\""
		"range\":[1,16384],\"values\":{\"1\":0,\"2\":12,\"4\":5,\"5\":0}},\"MEMORY_PHC_SLOTS_FREED\":{\"bucket_count\":64,\"histogram_type\":0,\"sum\":216,\"range\":[1,16384],\"values\":{\"7\":0,\"8\":1,\"11\":4,\"13\":12,\"15\":0}},\"SCRIPT_PRELOADER_REQUESTS\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":22,\"range\":[1,50],\"values\":{\"0\":15,\"2\":11,\"3\":0}},\"MASTER_PASSWORD_ENABLED\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\""
		"JS_PAGELOAD_PARSE_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":2,\"range\":[1,10000],\"values\":{\"0\":2,\"2\":1,\"3\":0}},\"CONTENT_PAINT_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":0,\"range\":[1,1000],\"values\":{\"0\":14,\"1\":0}},\"TIME_TO_DOM_LOADING_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":238,\"range\":[1,50000],\"values\":{\"45\":0,\"50\":1,\"55\":1,\"61\":1,\"67\":1,\"74\":0}},\"TIME_TO_DOM_INTERACTIVE_MS\":{\"bucket_count\":100,\"histogram_type\":0"
		",\"sum\":1037,\"range\":[1,50000],\"values\":{\"192\":0,\"211\":1,\"232\":1,\"255\":1,\"309\":1,\"340\":0}},\"TIME_TO_DOM_CONTENT_LOADED_START_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":1219,\"range\":[1,50000],\"values\":{\"211\":0,\"232\":1,\"309\":2,\"340\":1,\"374\":0}},\"TIME_TO_DOM_CONTENT_LOADED_END_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":1220,\"range\":[1,50000],\"values\":{\"211\":0,\"232\":1,\"309\":2,\"340\":1,\"374\":0}},\"TIME_TO_DOM_COMPLETE_MS\":{\""
		"bucket_count\":100,\"histogram_type\":0,\"sum\":1221,\"range\":[1,50000],\"values\":{\"211\":0,\"232\":1,\"309\":2,\"340\":1,\"374\":0}},\"TIME_TO_LOAD_EVENT_START_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":1221,\"range\":[1,50000],\"values\":{\"211\":0,\"232\":1,\"309\":2,\"340\":1,\"374\":0}},\"TIME_TO_LOAD_EVENT_END_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":1221,\"range\":[1,50000],\"values\":{\"211\":0,\"232\":1,\"309\":2,\"340\":1,\"374\":0}},\""
		"REL_PRELOAD_MISS_RATIO\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":19,\"1\":0}}},\"keyedHistograms\":{},\"scalars\":{\"telemetry.discarded.keyed_accumulations\":0,\"power.total_cpu_time_ms\":626,\"telemetry.discarded.child_events\":0,\"telemetry.discarded.accumulations\":0,\"script.preloader.mainthread_recompile\":1,\"telemetry.discarded.scalar_actions\":0,\"power.total_thread_wakeups\":2351,\"telemetry.discarded.keyed_scalar_actions\":0,\""
		"networking.http3_enabled\":true},\"keyedScalars\":{\"power.cpu_time_per_process_type_ms\":{\"extension\":626},\"power.wakeups_per_process_type\":{\"extension\":2351}}},\"dynamic\":{\"scalars\":{},\"keyedScalars\":{}},\"gpu\":{\"histograms\":{\"COMPOSITE_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":1056,\"range\":[1,1000],\"values\":{\"0\":2,\"1\":3,\"2\":10,\"3\":20,\"4\":15,\"5\":13,\"6\":8,\"7\":16,\"8\":14,\"9\":5,\"10\":4,\"11\":6,\"12\":12,\"14\":3,\"16\":5,\"18\":1,\"20\":3,\"33"
		"\":1,\"37\":1,\"42\":0}},\"GPU_PROCESS_INITIALIZATION_TIME_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":146,\"range\":[1,64000],\"values\":{\"125\":0,\"138\":1,\"152\":0}},\"KEYPRESS_PRESENT_LATENCY\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":122,\"range\":[1,200000],\"values\":{\"22\":0,\"28\":1,\"36\":1,\"46\":1,\"58\":0}},\"CONTENT_FULL_PAINT_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":412,\"range\":[1,1000],\"values\":{\"0\":1,\"1\":2,\"2\":23,\"3\":25,\"4\":13,"
		"\"5\":7,\"6\":3,\"7\":5,\"8\":4,\"9\":1,\"10\":2,\"12\":1,\"14\":3,\"16\":1,\"18\":1,\"20\":0}},\"CONTENT_FRAME_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":4023199,\"range\":[1,5000],\"values\":{\"18\":0,\"21\":3,\"25\":1,\"29\":4,\"34\":5,\"40\":1,\"47\":1,\"64\":4,\"75\":4,\"88\":8,\"103\":23,\"120\":18,\"140\":12,\"164\":1,\"192\":1,\"5000\":5}},\"CONTENT_FRAME_TIME_VSYNC\":{\"bucket_count\":100,\"histogram_type\":1,\"sum\":1997997,\"range\":[8,792],\"values\":{\"40\":0,\"48\":1,\""
		"88\":1,\"104\":2,\"112\":11,\"120\":6,\"128\":11,\"136\":7,\"144\":4,\"152\":1,\"160\":2,\"168\":2,\"176\":1,\"216\":1,\"224\":1,\"256\":1,\"272\":1,\"792\":2}},\"WR_RENDERER_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":408,\"range\":[1,1000],\"values\":{\"0\":64,\"1\":14,\"2\":5,\"3\":5,\"4\":14,\"5\":7,\"6\":10,\"7\":6,\"8\":2,\"9\":7,\"11\":2,\"12\":1,\"14\":1,\"18\":1,\"29\":1,\"33\":0}},\"WR_RENDERER_TIME_NO_SC_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":368,\"range\":"
		"[1,1000],\"values\":{\"0\":64,\"1\":14,\"2\":4,\"3\":5,\"4\":13,\"5\":7,\"6\":8,\"7\":6,\"8\":1,\"9\":7,\"11\":2,\"12\":1,\"18\":1,\"29\":1,\"33\":0}}},\"keyedHistograms\":{},\"scalars\":{\"telemetry.discarded.keyed_accumulations\":0,\"power.total_cpu_time_ms\":1510,\"telemetry.discarded.child_events\":0,\"telemetry.discarded.accumulations\":0,\"telemetry.discarded.scalar_actions\":0,\"power.total_thread_wakeups\":4162,\"telemetry.discarded.keyed_scalar_actions\":0},\"keyedScalars\":{\""
		"power.cpu_time_per_process_type_ms\":{\"gpu\":1510},\"power.wakeups_per_process_type\":{\"gpu\":4162}}},\"socket\":{\"histograms\":{},\"keyedHistograms\":{},\"scalars\":{\"telemetry.discarded.keyed_accumulations\":0,\"power.total_cpu_time_ms\":95,\"telemetry.discarded.child_events\":0,\"telemetry.discarded.accumulations\":0,\"telemetry.discarded.scalar_actions\":0,\"power.total_thread_wakeups\":154,\"telemetry.discarded.keyed_scalar_actions\":0},\"keyedScalars\":{\""
		"power.cpu_time_per_process_type_ms\":{\"socket\":95},\"power.wakeups_per_process_type\":{\"socket\":154}}},\"utility\":{\"histograms\":{},\"keyedHistograms\":{},\"scalars\":{\"telemetry.discarded.keyed_accumulations\":0,\"power.total_cpu_time_ms\":73,\"telemetry.discarded.child_events\":0,\"telemetry.discarded.accumulations\":0,\"telemetry.discarded.scalar_actions\":0,\"power.total_thread_wakeups\":165,\"telemetry.discarded.keyed_scalar_actions\":0},\"keyedScalars\":{\""
		"power.cpu_time_per_process_type_ms\":{\"utility\":73},\"power.wakeups_per_process_type\":{\"utility\":165}}}},\"histograms\":{\"A11Y_INSTANTIATED_FLAG\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"CHILD_PROCESS_LAUNCH_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":150,\"range\":[1,64000],\"values\":{\"2\":0,\"3\":1,\"9\":1,\"10\":1,\"13\":2,\"31\":1,\"34\":2,\"38\":0}},\"CONTENT_PROCESS_LAUNCH_MAINTHREAD_MS\":{\"bucket_count\":100,\""
		"histogram_type\":0,\"sum\":6,\"range\":[1,64000],\"values\":{\"1\":0,\"2\":3,\"3\":0}},\"CONTENT_PROCESS_LAUNCH_TOTAL_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":120,\"range\":[1,64000],\"values\":{\"31\":0,\"34\":1,\"42\":2,\"46\":0}},\"CONTENT_PROCESS_SYNC_LAUNCH_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":33,\"range\":[1,64000],\"values\":{\"14\":0,\"15\":1,\"17\":1,\"19\":0}},\"CONTENT_PROCESS_LAUNCH_IS_SYNC\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":2,\"range\""
		":[1,2],\"values\":{\"0\":3,\"1\":2,\"2\":0}},\"CYCLE_COLLECTOR_MAX_PAUSE\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":60,\"range\":[1,10000],\"values\":{\"2\":0,\"3\":5,\"4\":2,\"6\":3,\"17\":1,\"20\":0}},\"GC_ZONE_COUNT\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":16,\"range\":[1,100],\"values\":{\"2\":0,\"3\":4,\"4\":1,\"5\":0}},\"GC_ZONES_COLLECTED\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":12,\"range\":[1,100],\"values\":{\"0\":0,\"1\":2,\"3\":2,\"4\":1,\"5\":0}},\""
		"GC_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":285,\"range\":[1,10000],\"values\":{\"17\":0,\"20\":2,\"34\":1,\"81\":1,\"114\":1,\"135\":0}},\"GC_IN_PROGRESS_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":544,\"range\":[1,10000],\"values\":{\"57\":0,\"68\":1,\"81\":2,\"135\":1,\"160\":1,\"190\":0}},\"GC_BUDGET_WAS_INCREASED\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":23,\"1\":0}},\"GC_SLICE_WAS_LONG\":{\"bucket_count\":3,\""
		"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":23,\"1\":0}},\"GC_MAX_PAUSE_MS_2\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":170,\"range\":[1,10000],\"values\":{\"17\":0,\"20\":2,\"29\":1,\"40\":1,\"48\":1,\"57\":0}},\"GC_PREPARE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":28,\"range\":[1,1000],\"values\":{\"0\":3,\"2\":1,\"26\":1,\"29\":0}},\"GC_MARK_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":129,\"range\":[1,10000],\"values\":{\"12\":0,\"14\":2,\"24"
		"\":2,\"48\":1,\"57\":0}},\"GC_SWEEP_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":68,\"range\":[1,10000],\"values\":{\"3\":0,\"4\":1,\"5\":1,\"6\":1,\"12\":1,\"40\":1,\"48\":0}},\"GC_COMPACT_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":53,\"range\":[1,10000],\"values\":{\"40\":0,\"48\":1,\"57\":0}},\"GC_SLICE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":280,\"range\":[1,10000],\"values\":{\"0\":14,\"3\":1,\"20\":2,\"29\":2,\"34\":1,\"40\":2,\"48\":1,\"57\":0}},\""
		"GC_MMU_50\":{\"bucket_count\":20,\"histogram_type\":1,\"sum\":145,\"range\":[1,100],\"values\":{\"0\":1,\"1\":1,\"23\":1,\"51\":1,\"56\":1,\"62\":0}},\"GC_MINOR_US\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":53367,\"range\":[1,1000000],\"values\":{\"1\":0,\"2\":1,\"3\":1,\"13\":3,\"32\":1,\"36\":2,\"41\":3,\"47\":2,\"53\":1,\"60\":1,\"68\":1,\"88\":1,\"114\":1,\"130\":2,\"168\":2,\"191\":2,\"217\":1,\"247\":1,\"281\":2,\"364\":1,\"414\":2,\"536\":1,\"610\":2,\"791\":1,\"1026\":1,\"1330\""
		":3,\"1724\":2,\"2235\":2,\"2898\":1,\"3758\":1,\"4279\":1,\"4872\":1,\"7193\":1,\"8190\":1,\"9326\":0}},\"GC_TIME_BETWEEN_SLICES_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":250,\"range\":[1,2000],\"values\":{\"0\":2,\"2\":1,\"3\":1,\"15\":8,\"17\":4,\"22\":1,\"25\":1,\"29\":0}},\"GC_SLICE_COUNT\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":23,\"range\":[1,200],\"values\":{\"3\":0,\"4\":2,\"5\":3,\"6\":0}},\"DESERIALIZE_BYTES\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\""
		":5015424,\"range\":[16,2147483646],\"values\":{\"0\":0,\"16\":504,\"23\":7,\"34\":2,\"41\":6,\"50\":5,\"61\":5,\"74\":15,\"90\":29,\"109\":5,\"132\":1,\"160\":1,\"194\":5,\"235\":2,\"284\":231,\"344\":135,\"416\":235,\"503\":100,\"609\":70,\"737\":144,\"892\":93,\"1080\":110,\"1307\":20,\"1582\":14,\"1915\":73,\"2318\":112,\"2805\":20,\"3395\":26,\"4109\":17,\"4973\":16,\"6019\":8,\"7284\":16,\"8815\":100,\"10668\":27,\"12911\":2,\"15625\":5,\"18910\":4,\"22886\":8,\"27698\":1,\"33521\":5,\"40569"
		"\":3,\"49098\":5,\"87033\":1,\"105331\":3,\"484771\":1,\"586691\":0}},\"DESERIALIZE_ITEMS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":230335,\"range\":[1,2147483646],\"values\":{\"0\":0,\"1\":517,\"3\":26,\"5\":41,\"8\":3,\"12\":256,\"19\":504,\"30\":164,\"47\":203,\"73\":165,\"113\":82,\"176\":34,\"274\":27,\"426\":130,\"662\":10,\"1029\":12,\"1599\":13,\"2485\":1,\"6002\":4,\"9328\":0}},\"DESERIALIZE_US\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":64545,\"range\":[1,150000000],\""
		"values\":{\"0\":33,\"1\":319,\"2\":245,\"3\":140,\"4\":130,\"5\":152,\"6\":129,\"7\":113,\"8\":156,\"10\":89,\"12\":60,\"14\":72,\"17\":64,\"20\":66,\"24\":68,\"29\":52,\"35\":42,\"42\":29,\"50\":11,\"60\":29,\"72\":37,\"87\":29,\"105\":38,\"126\":20,\"151\":15,\"182\":11,\"219\":10,\"263\":11,\"316\":5,\"380\":2,\"457\":2,\"549\":2,\"660\":3,\"793\":1,\"1146\":1,\"1378\":1,\"1657\":2,\"1992\":2,\"3461\":1,\"4161\":0}},\"GEOLOCATION_ERROR\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\""
		"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"GPU_PROCESS_LAUNCH_TIME_MS_2\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":202,\"range\":[1,64000],\"values\":{\"168\":0,\"185\":1,\"204\":0}},\"MEMORY_RESIDENT_FAST\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":3859532,\"range\":[32768,16777216],\"values\":{\"207574\":0,\"221217\":17,\"235757\":0}},\"MEMORY_TOTAL\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":5212128,\"range\":[32768,16777216],\"values\":{\"267766\":0,\"285365\":3,"
		"\"304121\":14,\"324110\":0}},\"MEMORY_UNIQUE\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":2547528,\"range\":[32768,16777216],\"values\":{\"132939\":0,\"141677\":16,\"150989\":1,\"160913\":0}},\"MEMORY_JS_GC_HEAP\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":349184,\"range\":[1024,16777216],\"values\":{\"19382\":0,\"20356\":16,\"21379\":1,\"22453\":0}},\"GHOST_WINDOWS\":{\"bucket_count\":32,\"histogram_type\":0,\"sum\":0,\"range\":[1,128],\"values\":{\"0\":17,\"1\":0}},\""
		"MEMORY_PHC_SLOP\":{\"bucket_count\":48,\"histogram_type\":0,\"sum\":1911680,\"range\":[4096,8388608],\"values\":{\"80923\":0,\"95512\":15,\"112731\":2,\"133055\":0}},\"MEMORY_PHC_SLOTS_ALLOCATED\":{\"bucket_count\":64,\"histogram_type\":0,\"sum\":478,\"range\":[1,16384],\"values\":{\"23\":0,\"26\":17,\"30\":0}},\"MEMORY_PHC_SLOTS_FREED\":{\"bucket_count\":64,\"histogram_type\":0,\"sum\":724,\"range\":[1,16384],\"values\":{\"30\":0,\"35\":1,\"40\":14,\"46\":2,\"53\":0}},\"PROCESS_LIFETIME\":{\""
		"bucket_count\":24,\"histogram_type\":0,\"sum\":1039,\"range\":[15,86400],\"values\":{\"520\":0,\"771\":1,\"1142\":0}},\"SHUTDOWN_OK\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":1,\"range\":[1,2],\"values\":{\"0\":0,\"1\":1,\"2\":0}},\"HTTP_KBREAD_PER_CONN2\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":5,\"range\":[1,100000],\"values\":{\"0\":9,\"1\":3,\"2\":1,\"3\":0}},\"HTTP_TRANSACTION_IS_SSL\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":28,\"range\":[1,2],\"values\":{\"0\":26,"
		"\"1\":28,\"2\":0}},\"HTTP_SCHEME_UPGRADE_TYPE\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":29,\"range\":[1,50],\"values\":{\"0\":0,\"1\":29,\"2\":0}},\"TLS_EARLY_DATA_NEGOTIATED\":{\"bucket_count\":4,\"histogram_type\":1,\"sum\":0,\"range\":[1,3],\"values\":{\"0\":21,\"1\":0}},\"SSL_HANDSHAKE_VERSION\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":90,\"range\":[1,16],\"values\":{\"2\":0,\"3\":2,\"4\":21,\"5\":0}},\"SSL_HANDSHAKE_PRIVACY\":{\"bucket_count\":17,\"histogram_type\":1,\"sum"
		"\":29,\"range\":[1,16],\"values\":{\"0\":2,\"1\":17,\"3\":4,\"4\":0}},\"SSL_HANDSHAKE_RESULT\":{\"bucket_count\":673,\"histogram_type\":1,\"sum\":0,\"range\":[1,672],\"values\":{\"0\":23,\"1\":0}},\"SSL_HANDSHAKE_RESULT_FIRST_TRY\":{\"bucket_count\":673,\"histogram_type\":1,\"sum\":0,\"range\":[1,672],\"values\":{\"0\":22,\"1\":0}},\"SSL_HANDSHAKE_RESULT_CONSERVATIVE\":{\"bucket_count\":673,\"histogram_type\":1,\"sum\":0,\"range\":[1,672],\"values\":{\"0\":2,\"1\":0}},\""
		"SSL_HANDSHAKE_RESULT_ECH_GREASE\":{\"bucket_count\":673,\"histogram_type\":1,\"sum\":0,\"range\":[1,672],\"values\":{\"0\":21,\"1\":0}},\"SSL_TIME_UNTIL_READY\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":4076,\"range\":[1,60000],\"values\":{\"27\":0,\"28\":1,\"41\":1,\"58\":1,\"67\":1,\"84\":1,\"88\":1,\"100\":2,\"120\":2,\"165\":1,\"189\":1,\"198\":1,\"207\":2,\"217\":3,\"248\":2,\"310\":1,\"371\":1,\"406\":1,\"425\":0}},\"SSL_TIME_UNTIL_READY_FIRST_TRY\":{\"bucket_count\":200,\""
		"histogram_type\":0,\"sum\":4007,\"range\":[1,60000],\"values\":{\"27\":0,\"28\":1,\"41\":1,\"58\":1,\"84\":1,\"88\":1,\"100\":2,\"120\":2,\"165\":1,\"189\":1,\"198\":1,\"207\":2,\"217\":3,\"248\":2,\"310\":1,\"371\":1,\"406\":1,\"425\":0}},\"SSL_TIME_UNTIL_READY_CONSERVATIVE\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":130,\"range\":[1,60000],\"values\":{\"27\":0,\"28\":1,\"100\":1,\"105\":0}},\"SSL_TIME_UNTIL_READY_ECH_GREASE\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":3946,\""
		"range\":[1,60000],\"values\":{\"39\":0,\"41\":1,\"58\":1,\"67\":1,\"84\":1,\"88\":1,\"100\":1,\"120\":2,\"165\":1,\"189\":1,\"198\":1,\"207\":2,\"217\":3,\"248\":2,\"310\":1,\"371\":1,\"406\":1,\"425\":0}},\"SSL_BYTES_BEFORE_CERT_CALLBACK\":{\"bucket_count\":64,\"histogram_type\":0,\"sum\":69523,\"range\":[1,32000],\"values\":{\"2449\":0,\"2849\":16,\"3314\":2,\"3855\":2,\"4484\":1,\"5216\":0}},\"SSL_RESUMED_SESSION\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":2,\"range\":[1,2],\"values\":{"
		"\"0\":21,\"1\":2,\"2\":0}},\"CERT_VALIDATION_HTTP_REQUEST_RESULT\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":21,\"range\":[1,16],\"values\":{\"0\":0,\"1\":21,\"2\":0}},\"CERT_VALIDATION_HTTP_REQUEST_SUCCEEDED_TIME\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":1661,\"range\":[1,60000],\"values\":{\"11\":0,\"12\":1,\"17\":1,\"26\":1,\"33\":1,\"39\":1,\"53\":1,\"55\":5,\"58\":1,\"67\":1,\"76\":1,\"84\":2,\"120\":2,\"173\":1,\"181\":1,\"217\":1,\"227\":0}},\""
		"SSL_KEY_EXCHANGE_ALGORITHM_FULL\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":84,\"range\":[1,16],\"values\":{\"3\":0,\"4\":21,\"5\":0}},\"SSL_KEY_EXCHANGE_ALGORITHM_RESUMED\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":8,\"range\":[1,16],\"values\":{\"3\":0,\"4\":2,\"5\":0}},\"CERT_REVOCATION_MECHANISMS\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":79,\"range\":[1,50],\"values\":{\"1\":0,\"2\":8,\"3\":21,\"4\":0}},\"SPDY_KBREAD_PER_CONN2\":{\"bucket_count\":50,\"histogram_type\""
		":0,\"sum\":62,\"range\":[1,100000],\"values\":{\"0\":9,\"1\":2,\"2\":3,\"8\":1,\"39\":1,\"49\":0}},\"HTTP_CHANNEL_DISPOSITION\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":384,\"range\":[1,16],\"values\":{\"1\":0,\"2\":26,\"3\":3,\"8\":1,\"9\":5,\"10\":27,\"11\":0}},\"HTTP_CHANNEL_ONSTART_SUCCESS\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":67,\"range\":[1,2],\"values\":{\"0\":3,\"1\":67,\"2\":0}},\"TRANSACTION_WAIT_TIME_HTTP2_SUP_HTTP3\":{\"bucket_count\":100,\"histogram_type\":0,\""
		"sum\":64,\"range\":[1,5000],\"values\":{\"0\":5,\"62\":1,\"66\":0}},\"HTTP3_0RTT_STATE\":{\"bucket_count\":6,\"histogram_type\":1,\"sum\":0,\"range\":[1,5],\"values\":{\"0\":8,\"1\":0}},\"DNS_LOOKUP_METHOD2\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":501,\"range\":[1,16],\"values\":{\"0\":0,\"1\":98,\"2\":5,\"3\":6,\"6\":59,\"7\":3,\"8\":0}},\"DNS_LOOKUP_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":713,\"range\":[1,60000],\"values\":{\"0\":3,\"2\":8,\"3\":6,\"4\":4,\"7\":2,\"9"
		"\":2,\"11\":2,\"14\":2,\"17\":6,\"21\":9,\"26\":3,\"32\":4,\"40\":1,\"50\":0}},\"DNS_NATIVE_LOOKUP_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":941,\"range\":[1,60000],\"values\":{\"0\":7,\"1\":1,\"2\":12,\"3\":13,\"4\":10,\"5\":4,\"7\":2,\"9\":3,\"11\":2,\"14\":1,\"17\":3,\"21\":6,\"26\":11,\"32\":5,\"40\":1,\"50\":0}},\"DNS_NATIVE_QUEUING\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":115,\"range\":[1,60000],\"values\":{\"0\":64,\"1\":6,\"2\":1,\"3\":7,\"4\":1,\"5\":1,\"6\":1,\""
		"7\":3,\"14\":1,\"17\":2,\"21\":0}},\"DNS_FAILED_LOOKUP_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":12,\"range\":[1,60000],\"values\":{\"0\":4,\"5\":1,\"7\":1,\"9\":0}},\"DNS_BLACKLIST_COUNT\":{\"bucket_count\":20,\"histogram_type\":1,\"sum\":0,\"range\":[1,21],\"values\":{\"0\":2,\"1\":0}},\"STARTUP_CACHE_REQUESTS\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":317,\"range\":[1,50],\"values\":{\"0\":1,\"1\":177,\"2\":70,\"3\":0}},\"SCRIPT_PRELOADER_REQUESTS\":{\"bucket_count\":51,"
		"\"histogram_type\":5,\"sum\":510,\"range\":[1,50],\"values\":{\"0\":283,\"1\":20,\"2\":245,\"3\":0}},\"NETWORK_ID_ONLINE\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":3,\"range\":[1,50],\"values\":{\"0\":0,\"1\":3,\"2\":0}},\"URLCLASSIFIER_LOOKUP_TIME_2\":{\"bucket_count\":30,\"histogram_type\":0,\"sum\":2,\"range\":[1,5000],\"values\":{\"0\":13,\"1\":2,\"2\":0}},\"URLCLASSIFIER_SHUTDOWN_TIME\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":0,\"range\":[1,60000],\"values\":{\"0\":1,\"1\""
		":0}},\"URLCLASSIFIER_CL_CHECK_TIME\":{\"bucket_count\":10,\"histogram_type\":0,\"sum\":0,\"range\":[1,500],\"values\":{\"0\":15,\"1\":0}},\"URLCLASSIFIER_VLPS_FILELOAD_TIME\":{\"bucket_count\":10,\"histogram_type\":0,\"sum\":150,\"range\":[1,1000],\"values\":{\"0\":15,\"1\":3,\"2\":2,\"12\":1,\"29\":2,\"70\":0}},\"URLCLASSIFIER_VLPS_FALLOCATE_TIME\":{\"bucket_count\":10,\"histogram_type\":0,\"sum\":0,\"range\":[1,1000],\"values\":{\"0\":4,\"1\":0}},\"URLCLASSIFIER_VLPS_CONSTRUCT_TIME\":{\""
		"bucket_count\":15,\"histogram_type\":0,\"sum\":107,\"range\":[1,5000],\"values\":{\"0\":2,\"4\":1,\"55\":1,\"105\":0}},\"URLCLASSIFIER_VLPS_METADATA_CORRUPT\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":5,\"1\":0}},\"PLACES_AUTOCOMPLETE_6_FIRST_RESULTS_TIME_MS\":{\"bucket_count\":30,\"histogram_type\":0,\"sum\":75,\"range\":[50,1000],\"values\":{\"62\":0,\"69\":1,\"77\":0}},\"INPUT_EVENT_RESPONSE_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":1876,"
		"\"range\":[1,10000],\"values\":{\"0\":36,\"1\":13,\"2\":12,\"3\":15,\"4\":19,\"5\":13,\"6\":8,\"7\":6,\"8\":14,\"10\":16,\"12\":37,\"14\":31,\"17\":5,\"20\":4,\"24\":4,\"29\":2,\"34\":0}},\"INPUT_EVENT_RESPONSE_COALESCED_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":860,\"range\":[1,10000],\"values\":{\"0\":19,\"1\":6,\"2\":6,\"3\":3,\"4\":8,\"5\":7,\"6\":4,\"7\":3,\"8\":5,\"10\":6,\"12\":14,\"14\":17,\"17\":3,\"20\":1,\"24\":3,\"34\":1,\"40\":0}},\""
		"FX_SESSION_RESTORE_STARTUP_INIT_SESSION_MS\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":0,\"range\":[1,30000],\"values\":{\"0\":1,\"1\":0}},\"FX_SESSION_RESTORE_STARTUP_ONLOAD_INITIAL_WINDOW_MS\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":1,\"range\":[1,30000],\"values\":{\"0\":0,\"1\":1,\"2\":0}},\"FX_SESSION_RESTORE_ALL_FILES_CORRUPT\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"FX_SESSION_RESTORE_RESTORE_WINDOW_MS\":{\""
		"bucket_count\":10,\"histogram_type\":0,\"sum\":0,\"range\":[1,3000],\"values\":{\"0\":1,\"1\":0}},\"FX_URLBAR_ZERO_PREFIX_DWELL_TIME_MS\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":12947,\"range\":[1,60000],\"values\":{\"8678\":0,\"10758\":1,\"13336\":0}},\"MS_MESSAGE_REQUEST_TIME_MS\":{\"bucket_count\":20,\"histogram_type\":0,\"sum\":88,\"range\":[1,2000],\"values\":{\"0\":8,\"1\":2,\"3\":1,\"10\":2,\"15\":3,\"23\":0}},\"SEARCH_SERVICE_INIT2_MS\":{\"bucket_count\":50,\"histogram_type\":0,"
		"\"sum\":351,\"range\":[1,10000],\"values\":{\"268\":0,\"318\":1,\"378\":0}},\"TOUCH_ENABLED_DEVICE\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"SSL_SUCCESFUL_CERT_VALIDATION_TIME_MOZILLAPKIX\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":2249,\"range\":[1,60000],\"values\":{\"2\":0,\"3\":5,\"4\":1,\"7\":1,\"11\":1,\"14\":1,\"26\":1,\"40\":2,\"62\":2,\"77\":6,\"95\":2,\"118\":3,\"181\":2,\"224\":2,\"278\":0}},\""
		"MEDIA_SNIFFER_MP4_BRAND_PATTERN\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":20,\"range\":[1,50],\"values\":{\"9\":0,\"10\":2,\"11\":0}},\"BROWSER_IS_USER_DEFAULT\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":1,\"range\":[1,2],\"values\":{\"0\":0,\"1\":1,\"2\":0}},\"BROWSER_IS_USER_DEFAULT_ERROR\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"BROWSER_SET_DEFAULT_DIALOG_PROMPT_RAWCOUNT\":{\"bucket_count\":15,\"histogram_type\":0,\""
		"sum\":0,\"range\":[1,250],\"values\":{\"0\":1,\"1\":0}},\"BROWSER_SET_DEFAULT_ALWAYS_CHECK\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":1,\"range\":[1,2],\"values\":{\"0\":0,\"1\":1,\"2\":0}},\"MIXED_CONTENT_IMAGES\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":6,\"range\":[1,50],\"values\":{\"1\":0,\"2\":3,\"3\":0}},\"CONTENT_SIGNATURE_VERIFICATION_STATUS\":{\"bucket_count\":21,\"histogram_type\":1,\"sum\":0,\"range\":[1,20],\"values\":{\"0\":1,\"1\":0}},\"TLS_CIPHER_SUITE\":{\""
		"bucket_count\":65,\"histogram_type\":1,\"sum\":406,\"range\":[1,64],\"values\":{\"13\":0,\"14\":2,\"18\":21,\"19\":0}},\"SSL_KEA_ECDHE_CURVE_FULL\":{\"bucket_count\":37,\"histogram_type\":1,\"sum\":609,\"range\":[1,36],\"values\":{\"28\":0,\"29\":21,\"30\":0}},\"SSL_AUTH_ALGORITHM_FULL\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":138,\"range\":[1,16],\"values\":{\"3\":0,\"4\":3,\"7\":18,\"8\":0}},\"SSL_AUTH_RSA_KEY_SIZE_FULL\":{\"bucket_count\":25,\"histogram_type\":1,\"sum\":216,\"range\":"
		"[1,24],\"values\":{\"11\":0,\"12\":18,\"13\":0}},\"SSL_AUTH_ECDSA_CURVE_FULL\":{\"bucket_count\":37,\"histogram_type\":1,\"sum\":69,\"range\":[1,36],\"values\":{\"22\":0,\"23\":3,\"24\":0}},\"SSL_HANDSHAKE_TYPE\":{\"bucket_count\":9,\"histogram_type\":1,\"sum\":86,\"range\":[1,8],\"values\":{\"0\":0,\"1\":2,\"4\":21,\"5\":0}},\"SSL_OCSP_STAPLING\":{\"bucket_count\":9,\"histogram_type\":1,\"sum\":58,\"range\":[1,8],\"values\":{\"1\":0,\"2\":29,\"3\":0}},\"SSL_CERT_ERROR_OVERRIDES\":{\"bucket_count"
		"\":25,\"histogram_type\":1,\"sum\":29,\"range\":[1,24],\"values\":{\"0\":0,\"1\":29,\"2\":0}},\"SSL_PERMANENT_CERT_ERROR_OVERRIDES\":{\"bucket_count\":10,\"histogram_type\":0,\"sum\":0,\"range\":[1,1024],\"values\":{\"0\":1,\"1\":0}},\"CERT_EV_STATUS\":{\"bucket_count\":11,\"histogram_type\":1,\"sum\":29,\"range\":[1,10],\"values\":{\"0\":0,\"1\":29,\"2\":0}},\"CERT_VALIDATION_SUCCESS_BY_CA\":{\"bucket_count\":257,\"histogram_type\":1,\"sum\":5315,\"range\":[1,256],\"values\":{\"48\":0,\"49\":2,\""
		"181\":21,\"236\":6,\"237\":0}},\"CERT_PINNING_RESULTS\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":6,\"range\":[1,2],\"values\":{\"0\":0,\"1\":6,\"2\":0}},\"CERT_PINNING_MOZ_RESULTS_BY_HOST\":{\"bucket_count\":513,\"histogram_type\":1,\"sum\":474,\"range\":[1,512],\"values\":{\"12\":0,\"13\":6,\"33\":12,\"34\":0}},\"CERT_PINNING_MOZ_TEST_RESULTS_BY_HOST\":{\"bucket_count\":513,\"histogram_type\":1,\"sum\":32,\"range\":[1,512],\"values\":{\"14\":0,\"15\":1,\"17\":1,\"18\":0}},\""
		"CERT_CHAIN_KEY_SIZE_STATUS\":{\"bucket_count\":5,\"histogram_type\":1,\"sum\":29,\"range\":[1,4],\"values\":{\"0\":0,\"1\":29,\"2\":0}},\"MASTER_PASSWORD_ENABLED\":{\"bucket_count\":3,\"histogram_type\":3,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"COOKIE_BEHAVIOR\":{\"bucket_count\":16,\"histogram_type\":1,\"sum\":5,\"range\":[1,15],\"values\":{\"4\":0,\"5\":1,\"6\":0}},\"TRACKING_PROTECTION_ENABLED\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\""
		"0\":1,\"1\":0}},\"TRACKING_PROTECTION_PBM_DISABLED\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":1,\"1\":0}},\"QUERY_STRIPPING_COUNT\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":6,\"1\":0}},\"TIME_TO_FIRST_CONTENTFUL_PAINT_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":345,\"range\":[1,100000],\"values\":{\"289\":0,\"321\":1,\"356\":0}},\"INPUT_EVENT_QUEUED_KEYBOARD_MS\":{\"bucket_count\":100,\""
		"histogram_type\":0,\"sum\":403,\"range\":[1,5000],\"values\":{\"0\":1,\"1\":4,\"2\":2,\"3\":4,\"4\":3,\"5\":3,\"6\":2,\"8\":1,\"9\":1,\"10\":3,\"11\":3,\"12\":4,\"13\":3,\"14\":3,\"15\":2,\"16\":3,\"17\":2,\"23\":1,\"25\":0}},\"WEBEXT_BACKGROUND_PAGE_LOAD_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":3240,\"range\":[1,60000],\"values\":{\"651\":0,\"718\":1,\"792\":3,\"874\":0}},\"WEBEXT_EXTENSION_STARTUP_MS\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":923,\"range\":[1,50000],\""
		"values\":{\"144\":0,\"158\":1,\"174\":4,\"192\":0}},\"ORB_DID_EVER_BLOCK_RESPONSE\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":0,\"range\":[1,2],\"values\":{\"0\":12,\"1\":0}}},\"keyedHistograms\":{\"NETWORK_DNS_END_TO_CONNECT_START_EXP_MS\":{\"h2_0\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":3,\"range\":[1,2000],\"values\":{\"0\":5,\"1\":3,\"2\":0}}},\"SSL_TIME_UNTIL_HANDSHAKE_FINISHED_KEYED_BY_KA\":{\"x25519\":{\"bucket_count\":200,\"histogram_type\":0,\"sum\":4076,\"range\":[1,"
		"60000],\"values\":{\"27\":0,\"28\":1,\"41\":1,\"58\":1,\"67\":1,\"84\":1,\"88\":1,\"100\":2,\"120\":2,\"165\":1,\"189\":1,\"198\":1,\"207\":2,\"217\":3,\"248\":2,\"310\":1,\"371\":1,\"406\":1,\"425\":0}}},\"HTTP3_ECH_OUTCOME\":{\"GREASE\":{\"bucket_count\":33,\"histogram_type\":1,\"sum\":0,\"range\":[1,32],\"values\":{\"0\":8,\"1\":0}}},\"HTTP_CHANNEL_DISPOSITION_UPGRADE\":{\"enabledNoReason\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":55,\"range\":[1,50],\"values\":{\"0\":1,\"1\":3,\"2\""
		":26,\"3\":0}},\"enabledWont\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":61,\"range\":[1,50],\"values\":{\"1\":0,\"2\":26,\"3\":3,\"4\":0}},\"enabledUpgrade\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":4,\"range\":[1,50],\"values\":{\"0\":0,\"1\":2,\"2\":1,\"3\":0}}},\"HTTP3_CONNECTION_CLOSE_CODE_3\":{\"app_closed\":{\"bucket_count\":101,\"histogram_type\":1,\"sum\":72,\"range\":[1,100],\"values\":{\"17\":0,\"18\":4,\"19\":0}},\"transport_closed\":{\"bucket_count\":101,\""
		"histogram_type\":1,\"sum\":0,\"range\":[1,100],\"values\":{\"0\":4,\"1\":0}},\"app_closing\":{\"bucket_count\":101,\"histogram_type\":1,\"sum\":168,\"range\":[1,100],\"values\":{\"41\":0,\"42\":4,\"43\":0}}},\"HTTP3_CHANNEL_ONSTART_SUCCESS\":{\"no_http3\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":54,\"range\":[1,2],\"values\":{\"0\":3,\"1\":54,\"2\":0}}},\"DNS_LOOKUP_DISPOSITION3\":{\"mozilla.cloudflare-dns.com\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":528,\"range\":[1,50],\""
		"values\":{\"5\":0,\"6\":81,\"7\":6,\"8\":0}}},\"URLCLASSIFIER_CL_KEYED_UPDATE_TIME\":{\"google4\":{\"bucket_count\":30,\"histogram_type\":0,\"sum\":1702,\"range\":[20,120000],\"values\":{\"1121\":0,\"1531\":1,\"2091\":0}}},\"URLCLASSIFIER_UPDATE_REMOTE_NETWORK_ERROR\":{\"google4\":{\"bucket_count\":31,\"histogram_type\":1,\"sum\":0,\"range\":[1,30],\"values\":{\"0\":1,\"1\":0}}},\"URLCLASSIFIER_UPDATE_REMOTE_STATUS2\":{\"google4\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":1,\"range\":[1,16"
		"],\"values\":{\"0\":0,\"1\":1,\"2\":0}}},\"URLCLASSIFIER_UPDATE_SERVER_RESPONSE_TIME\":{\"google4\":{\"bucket_count\":30,\"histogram_type\":0,\"sum\":524,\"range\":[1,100000],\"values\":{\"343\":0,\"514\":1,\"771\":0}}},\"URLCLASSIFIER_UPDATE_TIMEOUT\":{\"google4\":{\"bucket_count\":5,\"histogram_type\":1,\"sum\":0,\"range\":[1,4],\"values\":{\"0\":1,\"1\":0}}},\"URLCLASSIFIER_UPDATE_ERROR\":{\"google4\":{\"bucket_count\":17,\"histogram_type\":1,\"sum\":0,\"range\":[1,16],\"values\":{\"0\":1,\"1\""
		":0}}},\"SEARCH_SUGGESTIONS_LATENCY_MS\":{\"google-b-d\":{\"bucket_count\":50,\"histogram_type\":0,\"sum\":149,\"range\":[1,30000],\"values\":{\"115\":0,\"140\":1,\"171\":0}}},\"WEBEXT_BACKGROUND_PAGE_LOAD_MS_BY_ADDONID\":{\"formautofill@mozilla.org\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":739,\"range\":[1,60000],\"values\":{\"651\":0,\"718\":1,\"792\":0}},\"pictureinpicture@mozilla.org\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":824,\"range\":[1,60000],\"values\":{\"718\":0,\""
		"792\":1,\"874\":0}},\"webcompat@mozilla.org\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":857,\"range\":[1,60000],\"values\":{\"718\":0,\"792\":1,\"874\":0}},\"addons-search-detection@mozilla.com\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":820,\"range\":[1,60000],\"values\":{\"718\":0,\"792\":1,\"874\":0}}},\"WEBEXT_EXTENSION_STARTUP_MS_BY_ADDONID\":{\"default-theme@mozilla.org\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":169,\"range\":[1,50000],\"values\":{\"144\":0,\"158"
		"\":1,\"174\":0}},\"pictureinpicture@mozilla.org\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":187,\"range\":[1,50000],\"values\":{\"158\":0,\"174\":1,\"192\":0}},\"webcompat@mozilla.org\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":187,\"range\":[1,50000],\"values\":{\"158\":0,\"174\":1,\"192\":0}},\"addons-search-detection@mozilla.com\":{\"bucket_count\":100,\"histogram_type\":0,\"sum\":190,\"range\":[1,50000],\"values\":{\"158\":0,\"174\":1,\"192\":0}},\"formautofill@mozilla.org\":"
		"{\"bucket_count\":100,\"histogram_type\":0,\"sum\":190,\"range\":[1,50000],\"values\":{\"158\":0,\"174\":1,\"192\":0}}},\"QM_FIRST_INITIALIZATION_ATTEMPT\":{\"Storage\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":1,\"range\":[1,2],\"values\":{\"0\":0,\"1\":1,\"2\":0}},\"PersistentOrigin\":{\"bucket_count\":3,\"histogram_type\":2,\"sum\":1,\"range\":[1,2],\"values\":{\"0\":0,\"1\":1,\"2\":0}}},\"QM_SHUTDOWN_TIME_V0\":{\"Normal\":{\"bucket_count\":60,\"histogram_type\":0,\"sum\":5,\"range\":[1,"
		"60000],\"values\":{\"4\":0,\"5\":1,\"6\":0}}},\"HTTP_TRAFFIC_ANALYSIS_3\":{\"Connection\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":16,\"range\":[1,50],\"values\":{\"0\":24,\"2\":8,\"3\":0}},\"Transaction\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":26,\"range\":[1,50],\"values\":{\"0\":42,\"2\":13,\"3\":0}}},\"SQLITE_STORE_OPEN\":{\"permissions.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\":0}},\""
		"2823318777ntouromlalnodry--naod.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"cookies.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"2918063365piupsah.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"3561288849sdhlie.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2"
		",\"1\":0}},\"ls-archive.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":2,\"1\":0}},\"bounce-tracking-protection.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\":0}},\"content-prefs.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\":0}},\"1657114595AmcateirvtiSty.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\""
		"values\":{\"0\":7,\"1\":0}},\"protections.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\":0}},\"places.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":4,\"1\":0}},\"storage.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\":0}},\"formhistory.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\""
		":0}},\"3870112724rsegmnoittet-es.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":4,\"1\":0}},\"webappsstore.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":1,\"1\":0}},\"1451318868ntouromlalnodry--epcr.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":3,\"1\":0}}},\"SQLITE_STORE_QUERY\":{\"permissions.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum"
		"\":0,\"range\":[1,50],\"values\":{\"0\":7,\"1\":0}},\"2823318777ntouromlalnodry--naod.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":22,\"1\":0}},\"cookies.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":16,\"1\":0}},\"2918063365piupsah.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":32,\"1\":0}},\"3561288849sdhlie.sqlite\":{\"bucket_count\":51,\""
		"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":22,\"1\":0}},\"ls-archive.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":21,\"1\":0}},\"bounce-tracking-protection.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":7,\"1\":0}},\"content-prefs.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":15,\"1\":0}},\"1657114595AmcateirvtiSty.sqlite\":{\""
		"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":166,\"1\":0}},\"protections.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":9,\"1\":0}},\"places.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":181,\"1\":0}},\"storage.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":6,\"1\":0}},\"formhistory.sqlite\":{\"bucket_count\":51,"
		"\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":7,\"1\":0}},\"3870112724rsegmnoittet-es.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":95,\"1\":0}},\"webappsstore.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":14,\"1\":0}},\"1451318868ntouromlalnodry--epcr.sqlite\":{\"bucket_count\":51,\"histogram_type\":5,\"sum\":0,\"range\":[1,50],\"values\":{\"0\":32,\"1\":0}}},\""
		"HTTP_CONNECTION_CLOSE_REASON\":{\"11_1_0_1_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":102,\"range\":[1,50],\"values\":{\"16\":0,\"17\":6,\"18\":0}},\"20_1_0_7_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":132,\"range\":[1,50],\"values\":{\"17\":0,\"18\":1,\"19\":6,\"20\":0}},\"30_1_0_0_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":16,\"range\":[1,50],\"values\":{\"1\":0,\"2\":8,\"3\":0}},\"11_0_0_0_1\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":32,\"range\":[1,50]"
		",\"values\":{\"15\":0,\"16\":2,\"17\":0}},\"20_1_0_3_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":132,\"range\":[1,50],\"values\":{\"17\":0,\"18\":1,\"19\":6,\"20\":0}},\"11_0_0_0_0\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":30,\"range\":[1,50],\"values\":{\"4\":0,\"5\":6,\"6\":0}},\"11_1_0_3_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":35,\"range\":[1,50],\"values\":{\"15\":0,\"16\":1,\"19\":1,\"20\":0}},\"11_0_0_7_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\""
		":208,\"range\":[1,50],\"values\":{\"15\":0,\"16\":13,\"17\":0}},\"11_1_0_7_4\":{\"bucket_count\":51,\"histogram_type\":1,\"sum\":17,\"range\":[1,50],\"values\":{\"16\":0,\"17\":1,\"18\":0}}}},\"info\":{\"reason\":\"shutdown\",\"revision\":\"https://hg.mozilla.org/releases/mozilla-release/rev/38b9888273f81488e7b45457790717820815e1d2\",\"timezoneOffset\":0,\"previousBuildId\":null,\"sessionId\":\"89066759-a4ea-4f62-ae22-b071c7fddde5\",\"subsessionId\":\"f31b745b-f89d-4979-8675-545f6e0bee2a\",\""
		"previousSessionId\":\"e1846d0a-542b-4c0c-be76-8a7f46c4cc4e\",\"previousSubsessionId\":\"a0345a6f-6c84-474d-a786-430f1d98da7d\",\"subsessionCounter\":1,\"profileSubsessionCounter\":5,\"sessionStartDate\":\"2024-07-31T05:00:00.0+00:00\",\"subsessionStartDate\":\"2024-07-31T05:00:00.0+00:00\",\"sessionLength\":1041,\"subsessionLength\":1040,\"addons\":\"formautofill%40mozilla.org:1.0.1,pictureinpicture%40mozilla.org:1.0.0,webcompat%40mozilla.org:128.3.0,default-theme%40mozilla.org:1.3,"
		"addons-search-detection%40mozilla.com:2.0.0\"}},\"clientId\":\"822571c1-9c9d-4d99-8bbb-5171f4f2a291\",\"environment\":{\"build\":{\"applicationId\":\"{ec8030f7-c20a-464f-9b0e-13a3a9e97384}\",\"applicationName\":\"Firefox\",\"architecture\":\"x86-64\",\"buildId\":\"20240725162350\",\"version\":\"128.0.3\",\"vendor\":\"Mozilla\",\"displayVersion\":\"128.0.3\",\"platformVersion\":\"128.0.3\",\"xpcomAbi\":\"x86_64-msvc\",\"updaterAvailable\":true},\"partner\":{\"distributionId\":null,\""
		"distributionVersion\":null,\"partnerId\":null,\"distributor\":null,\"distributorChannel\":null,\"partnerNames\":[]},\"system\":{\"memoryMB\":16196,\"virtualMaxMB\":134217728,\"cpu\":{\"isWindowsSMode\":false,\"count\":4,\"cores\":2,\"vendor\":\"GenuineIntel\",\"name\":\"Intel(R) Xeon(R) Platinum 8259CL CPU @ 2.50GHz\",\"family\":6,\"model\":85,\"stepping\":7,\"l2cacheKB\":1024,\"l3cacheKB\":36608,\"speedMHz\":2500,\"extensions\":[\"hasMMX\",\"hasSSE\",\"hasSSE2\",\"hasSSE3\",\"hasSSSE3\",\""
		"hasSSE4_1\",\"hasSSE4_2\",\"hasAVX\",\"hasAVX2\",\"hasAES\"]},\"os\":{\"installYear\":2022,\"hasSuperfetch\":true,\"hasPrefetch\":false,\"name\":\"Windows_NT\",\"version\":\"10.0\",\"locale\":\"en-US\",\"servicePackMajor\":0,\"servicePackMinor\":0,\"windowsBuildNumber\":20348,\"windowsUBR\":887},\"hdd\":{\"binary\":{\"model\":\"NVMe Amazon Elastic B\",\"revision\":\"1.0\",\"type\":\"HDD\"},\"profile\":{\"model\":\"NVMe Amazon Elastic B\",\"revision\":\"1.0\",\"type\":\"HDD\"},\"system\":{\"model\""
		":\"NVMe Amazon Elastic B\",\"revision\":\"1.0\",\"type\":\"HDD\"}},\"gfx\":{\"D2DEnabled\":false,\"DWriteEnabled\":true,\"ContentBackend\":\"Skia\",\"Headless\":false,\"EmbeddedInFirefoxReality\":false,\"TargetFrameRate\":32,\"adapters\":[{\"description\":\"Microsoft Remote Display Adapter\",\"vendorID\":\"0x000d\",\"deviceID\":\"0x000d\",\"subsysID\":\"0000000d\",\"RAM\":0,\"driver\":\"Unknown\",\"driverVendor\":null,\"driverVersion\":null,\"driverDate\":null,\"GPUActive\":true}],\"monitors\":[{"
		"\"screenWidth\":1280,\"screenHeight\":544,\"refreshRate\":32,\"pseudoDisplay\":false}],\"features\":{\"compositor\":\"webrender_software\",\"hwCompositing\":{\"status\":\"available\"},\"gpuProcess\":{\"status\":\"available\"},\"webrender\":{\"status\":\"blocklisted:FEATURE_FAILURE_UNKNOWN_DEVICE_VENDOR\"},\"wrCompositor\":{\"status\":\"unavailable:FEATURE_FAILURE_DCOMP_NOT_ANGLE\"},\"openglCompositing\":{\"status\":\"unused\"},\"omtp\":{\"status\":\"unused\"},\"d3d11\":{\"status\":\"blocklisted"
		":FEATURE_FAILURE_UNKNOWN_DEVICE_VENDOR\"},\"d2d\":{\"status\":\"unavailable:FEATURE_FAILURE_D2D_D3D11_COMP\",\"version\":\"1.1\"}}},\"appleModelId\":null,\"hasWinPackageId\":false,\"sec\":{\"antivirus\":null,\"antispyware\":null,\"firewall\":null},\"isWow64\":false,\"isWowARM64\":false},\"settings\":{\"blocklistEnabled\":true,\"e10sEnabled\":true,\"e10sMultiProcesses\":8,\"fissionEnabled\":true,\"telemetryEnabled\":false,\"locale\":\"en-US\",\"intl\":{\"requestedLocales\":[\"en-US\"],\""
		"availableLocales\":[\"en-US\"],\"appLocales\":[\"en-US\"],\"systemLocales\":[\"en-US\"],\"regionalPrefsLocales\":[\"en-US\"],\"acceptLanguages\":[\"en-US\",\"en\"]},\"update\":{\"channel\":\"release\",\"enabled\":true,\"autoDownload\":true,\"background\":true},\"userPrefs\":{\"browser.search.region\":\"IN\",\"browser.search.widget.inNavBar\":false,\"browser.urlbar.autoFill\":true,\"browser.urlbar.autoFill.adaptiveHistory.enabled\":false,\"browser.urlbar.dnsResolveSingleWordsAfterSearch\":0,\""
		"browser.urlbar.quicksuggest.dataCollection.enabled\":false,\"browser.urlbar.suggest.quicksuggest.nonsponsored\":false,\"browser.urlbar.suggest.quicksuggest.sponsored\":false,\"media.gmp-gmpopenh264.lastInstallStart\":1722402463,\"media.gmp-gmpopenh264.lastDownload\":1722402463,\"media.gmp-gmpopenh264.lastUpdate\":1722402463,\"media.gmp-widevinecdm.lastInstallStart\":1722402463,\"media.gmp-widevinecdm.lastDownload\":1722402464,\"media.gmp-widevinecdm.lastUpdate\":1722402465,\""
		"media.gmp-manager.lastCheck\":1722403476,\"media.gmp-manager.lastEmptyCheck\":1722403476,\"network.trr.strict_native_fallback\":false,\"widget.content.gtk-high-contrast.enabled\":true},\"sandbox\":{\"effectiveContentProcessLevel\":7,\"contentWin32kLockdownState\":15},\"launcherProcessState\":0,\"addonCompatibilityCheckEnabled\":true,\"isDefaultBrowser\":true,\"attribution\":{\"campaign\":\"%2528not%2Bset%2529\",\"content\":\"%2528not%2Bset%2529\",\"dlsource\":\"mozorg\",\"dltoken\":\""
		"f8162e47-451d-4534-80e8-3cd383d164ec\",\"experiment\":\"%2528not%2Bset%2529\",\"medium\":\"%2528direct%2529\",\"source\":\"%2528not%2Bset%2529\",\"ua\":\"chrome\",\"variation\":\"%2528not%2Bset%2529\"},\"defaultSearchEngine\":\"google-b-d\",\"defaultSearchEngineData\":{\"loadPath\":\"[app]google@search.mozilla.org\",\"name\":\"Google\",\"origin\":\"default\",\"submissionURL\":\"https://www.google.com/search?client=firefox-b-d&q=\"}},\"profile\":{\"creationDate\":19935,\"firstUseDate\":19935},\""
		"addons\":{\"activeAddons\":{\"formautofill@mozilla.org\":{\"version\":\"1.0.1\",\"scope\":1,\"type\":\"extension\",\"updateDay\":19929,\"isSystem\":true,\"isWebExtension\":true,\"multiprocessCompatible\":true,\"blocklisted\":false,\"description\":null,\"name\":\"Form Autofill\",\"userDisabled\":false,\"appDisabled\":false,\"foreignInstall\":false,\"hasBinaryComponents\":false,\"installDay\":19929,\"quarantineIgnoredByApp\":true,\"quarantineIgnoredByUser\":false},\"pictureinpicture@mozilla.org\":{"
		"\"version\":\"1.0.0\",\"scope\":1,\"type\":\"extension\",\"updateDay\":19929,\"isSystem\":true,\"isWebExtension\":true,\"multiprocessCompatible\":true,\"blocklisted\":false,\"description\":\"Fixes for web compatibility with Picture-in-Picture\",\"name\":\"Picture-In-Picture\",\"userDisabled\":false,\"appDisabled\":false,\"foreignInstall\":false,\"hasBinaryComponents\":false,\"installDay\":19929,\"quarantineIgnoredByApp\":true,\"quarantineIgnoredByUser\":false},\"webcompat@mozilla.org\":{\"version"
		"\":\"128.3.0\",\"scope\":1,\"type\":\"extension\",\"updateDay\":19929,\"isSystem\":true,\"isWebExtension\":true,\"multiprocessCompatible\":true,\"blocklisted\":false,\"description\":\"Urgent post-release fixes for web compatibility.\",\"name\":\"Web Compatibility Interventions\",\"userDisabled\":false,\"appDisabled\":false,\"foreignInstall\":false,\"hasBinaryComponents\":false,\"installDay\":19929,\"quarantineIgnoredByApp\":true,\"quarantineIgnoredByUser\":false}},\"theme\":{\"id\":\""
		"default-theme@mozilla.org\",\"blocklisted\":false,\"description\":\"Follow the operating system setting for buttons, menus, and windows.\",\"name\":\"System theme \\xE2\\x80\\x94 auto\",\"userDisabled\":false,\"appDisabled\":false,\"version\":\"1.3\",\"scope\":4,\"foreignInstall\":false,\"hasBinaryComponents\":false,\"installDay\":19935,\"updateDay\":19935},\"activeGMPlugins\":{\"gmp-gmpopenh264\":{\"version\":\"2.3.2\",\"userDisabled\":false,\"applyBackgroundUpdates\":1},\"gmp-widevinecdm\":{\""
		"version\":\"4.10.2710.0\",\"userDisabled\":false,\"applyBackgroundUpdates\":1}}},\"experiments\":{\"long-term-holdback-2024-h2-velocity-desktop\":{\"branch\":\"delivery\",\"type\":\"nimbus-nimbus\"},\"recommend-add-ons-staff-pick-part-2\":{\"branch\":\"treatment-b\",\"type\":\"nimbus-nimbus\"},\"pin-email-and-calendar-tabs-early-day-user\":{\"branch\":\"treatment-a\",\"type\":\"nimbus-nimbus\"},\"add-an-image-to-pdf-with-alt-text-rollout\":{\"branch\":\"control\",\"type\":\"nimbus-rollout\"},\""
		"backgroundupdate-enable-unelevated-installations-rollout-3-release\":{\"branch\":\"enabled\",\"type\":\"nimbus-rollout\"},\"csv-import-release-rollout\":{\"branch\":\"enable-csv-import\",\"type\":\"nimbus-rollout\"},\"ech-roll-out\":{\"branch\":\"rollout\",\"type\":\"nimbus-rollout\"},\"upgrade-spotlight-rollout\":{\"branch\":\"treatment\",\"type\":\"nimbus-rollout\"},\"launch-firefox-on-os-restart-treatment-a-rollout\":{\"branch\":\"treatment-a\",\"type\":\"nimbus-rollout\"},\"phc-rollout\":{\""
		"branch\":\"rollout\",\"type\":\"nimbus-rollout\"},\"highlighting-in-pdfs-rollout\":{\"branch\":\"treatment\",\"type\":\"nimbus-rollout\"},\"consolidated-search-configuration-row-desktop-relaunch\":{\"branch\":\"rollout\",\"type\":\"nimbus-rollout\"},\"disable-redirects-for-authretries\":{\"branch\":\"control\",\"type\":\"nimbus-rollout\"},\"home-and-newtab-wallpapers-v1-rollout-global\":{\"branch\":\"control\",\"type\":\"nimbus-rollout\"}}}}", 
		LAST);

	web_url("canonical.html_2", 
		"URL=http://detectportal.firefox.com/canonical.html", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=/success.txt?ipv4", "Referer=", ENDITEM, 
		LAST);

	web_submit_data("staff_login.php_2", 
		"Action=http://localhost/banking/staff_login.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_login.php", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=staff_id", "Value=210001", ENDITEM, 
		"Name=password", "Value=password", ENDITEM, 
		"Name=staff_login-btn", "Value=LOGIN", ENDITEM, 
		EXTRARES, 
		"Url=img/customers/No_image.jpg", "Referer=http://localhost/banking/staff_profile.php", ENDITEM, 
		LAST);

	lr_end_transaction("TR03_Login",LR_AUTO);

	lr_start_transaction("TR04_ApprovePendingAccount");

	web_submit_data("staff_profile.php", 
		"Action=http://localhost/banking/staff_profile.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/staff_profile.php", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=apprvac", "Value=Approve Pending Account", ENDITEM, 
		LAST);

	lr_end_transaction("TR04_ApprovePendingAccount",LR_AUTO);

	lr_think_time(39);

	lr_start_transaction("TR05_ApplicationNumber");

	web_submit_data("pending_customers.php", 
		"Action=http://localhost/banking/pending_customers.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/banking/pending_customers.php", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=application_no", "Value=302415193", ENDITEM, 
		"Name=search_application", "Value=Search", ENDITEM, 
		LAST);

	return 0;
}